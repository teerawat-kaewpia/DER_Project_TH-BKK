Folder: Scripts/02_Preprocessing
Description: Resample → 3 arc-sec standardization
Created: 2026-06-15
Project: Thailand DER Digital Twin — Net-Zero Energy Planning
