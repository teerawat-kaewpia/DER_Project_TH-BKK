"""
C2: Energy Poverty Index from VIIRS NTL
========================================
Formula: C2_province = max(0, 1 - NTL_per_capita_province / national_mean)

  NTL_per_capita_province = sum(NTL pixels in province) / sum(WorldPop pixels in province)
  national_mean           = national NTL sum / national population

Province with low NTL per capita → high C2 → high energy poverty → high DER priority (Benefit ↑)

Sources:
  - VIIRS DNB annual composite 2022 (90m, EPSG:4326)
  - WorldPop 2020 100m UN-adjusted (resampled to 90m)
  - GADM 4.1 province boundaries

Reference: Shi et al. (2014) Remote Sensing; Min et al. (2013) Science
Output: DER/Data/14_Processed_90m/C2_energy_poverty_90m.tif
"""

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.warp import reproject, Resampling
from rasterio.features import rasterize
from rasterstats import zonal_stats
from pathlib import Path
import os
import fiona

BASE       = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))
NTL_TIF    = BASE / "Energy map" / "Thailand_NTL_2022_90m.tif"
WORLDPOP   = BASE / "DER" / "Data" / "05_Population" / "worldpop_THA_2020_100m.tif"
GADM_GPKG  = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
REF_GRID   = BASE / "Energy map" / "Thailand_DEM_90m.tif"
OUTPUT_TIF = BASE / "DER" / "Data" / "14_Processed_90m" / "C2_energy_poverty_90m.tif"

NODATA_OUT = -9999.0

# ── Reference grid ─────────────────────────────────────────────────────────────
print("Reading reference grid...")
with rasterio.open(REF_GRID) as ref:
    ref_transform = ref.transform
    ref_crs       = ref.crs
    ref_width     = ref.width
    ref_height    = ref.height

print(f"  Grid: {ref_width}x{ref_height}, CRS={ref_crs}")

# ── Load NTL (already at 90m reference grid) ───────────────────────────────────
print("Loading NTL 2022...")
with rasterio.open(NTL_TIF) as src:
    ntl = src.read(1).astype("float32")
    ntl = np.where(np.isnan(ntl), 0.0, ntl)
    ntl = np.where(ntl < 0, 0.0, ntl)
print(f"  NTL range: 0 – {ntl.max():.2f} nW/cm²/sr")

# ── Resample WorldPop to 90m ───────────────────────────────────────────────────
print("Resampling WorldPop to 90m...")
pop_90m = np.zeros((ref_height, ref_width), dtype="float32")
with rasterio.open(WORLDPOP) as src:
    wp_nodata = src.nodata if src.nodata is not None else -9999
    reproject(
        source=rasterio.band(src, 1),
        destination=pop_90m,
        src_transform=src.transform,
        src_crs=src.crs,
        dst_transform=ref_transform,
        dst_crs=ref_crs,
        resampling=Resampling.bilinear,
        src_nodata=wp_nodata,
        dst_nodata=0.0,
    )
pop_90m = np.where(pop_90m < 0, 0.0, pop_90m)

# ── Load province boundaries ───────────────────────────────────────────────────
print("Loading GADM provinces...")
layers = fiona.listlayers(str(GADM_GPKG))
adm1_layer = next((l for l in layers if l.endswith("_1")), layers[1])
provinces = gpd.read_file(str(GADM_GPKG), layer=adm1_layer)
provinces = provinces[["GID_1", "geometry"]].copy()
if provinces.crs != ref_crs:
    provinces = provinces.to_crs(ref_crs)
print(f"  Provinces: {len(provinces)}")

# ── Zonal stats: NTL sum and population sum per province ──────────────────────
print("Computing zonal stats (NTL + population per province)...")

ntl_stats = zonal_stats(provinces, ntl, affine=ref_transform,
                         stats=["sum"], nodata=0.0, all_touched=False)
pop_stats  = zonal_stats(provinces, pop_90m, affine=ref_transform,
                         stats=["sum"], nodata=0.0, all_touched=False)

provinces["ntl_sum"] = [s["sum"] or 0.0 for s in ntl_stats]
provinces["pop_sum"] = [s["sum"] or 0.0 for s in pop_stats]

# ── NTL per capita per province ────────────────────────────────────────────────
provinces["ntl_per_capita"] = np.where(
    provinces["pop_sum"] > 0,
    provinces["ntl_sum"] / provinces["pop_sum"],
    0.0
)

national_ntl  = provinces["ntl_sum"].sum()
national_pop  = provinces["pop_sum"].sum()
national_mean = national_ntl / national_pop if national_pop > 0 else 1.0

print(f"  National NTL sum: {national_ntl:.2f}")
print(f"  National pop:     {national_pop:,.0f}")
print(f"  National NTL/cap: {national_mean:.6f}")
print(f"  Province range:   {provinces['ntl_per_capita'].min():.6f} – {provinces['ntl_per_capita'].max():.6f}")

# ── C2 formula ─────────────────────────────────────────────────────────────────
provinces["C2"] = np.clip(1.0 - provinces["ntl_per_capita"] / national_mean, 0.0, 1.0)
print(f"  C2 range: {provinces['C2'].min():.4f} – {provinces['C2'].max():.4f}")
print(f"  Top 5 energy-poor provinces:")
top5 = provinces.nlargest(5, "C2")[["GID_1", "ntl_per_capita", "C2"]]
print(top5.to_string(index=False))

# ── Rasterize C2 to 90m reference grid ────────────────────────────────────────
print("Rasterizing C2 to 90m...")
shapes = (
    (geom, val)
    for geom, val in zip(provinces.geometry, provinces["C2"])
    if geom is not None and not pd.isna(val)
)
c2_raster = rasterize(
    shapes,
    out_shape=(ref_height, ref_width),
    transform=ref_transform,
    fill=NODATA_OUT,
    dtype="float32",
    all_touched=False,
)

# ── Write output ───────────────────────────────────────────────────────────────
print(f"Writing: {OUTPUT_TIF}")
profile = {
    "driver": "GTiff", "dtype": "float32",
    "width": ref_width, "height": ref_height, "count": 1,
    "crs": ref_crs, "transform": ref_transform,
    "nodata": NODATA_OUT, "compress": "lzw",
    "tiled": True, "blockxsize": 512, "blockysize": 512,
}
with rasterio.open(OUTPUT_TIF, "w", **profile) as dst:
    dst.write(c2_raster, 1)
    dst.update_tags(
        description="C2 Energy Poverty Index (NTL-based)",
        formula="max(0, 1 - NTL_per_capita_province / national_mean)",
        ntl_source="VIIRS DNB annual composite 2022",
        pop_source="WorldPop 2020 100m UN-adjusted",
        national_ntl_per_capita=f"{national_mean:.6f}",
        created="2026-07-07",
    )

print("\nDone.")
print(f"  Output: {OUTPUT_TIF}")
print(f"  Valid pixels: {(c2_raster != NODATA_OUT).sum():,}")
