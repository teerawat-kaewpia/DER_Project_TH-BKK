"""
C4 Proxy: Emission Reduction Potential (ERP) Raster
=====================================================
Replaces CNI (Paper P2) as C4 criterion for DER priority analysis.

Formula: ERP_i = pop_density_i x elec_per_capita_province x EFEC
  - pop_density_i  : WorldPop 2020 pixel value (persons/km²) resampled to 90m
  - elec_per_capita: EPPO 2022 province electricity (kWh) / province population
  - EFEC           : TGO Grid EF 2022 = 0.4682 tCO2/MWh = 0.0004682 tCO2/kWh

Output unit: tCO2/km²/year (normalized to [0,1] at 2nd-98th percentile)

Sources:
  - EPPO: Provincial electricity consumption 2022
  - GADM 4.1: Province boundaries (GID_1)
  - WorldPop 2020 100m (UN-adjusted)
  - TGO Emission Factor (announced 28 May B.E. 2568): EFEC 2022 = 0.4682 tCO2/MWh
  - Reference grid: Thailand_DEM_90m.tif (Copernicus GLO-30)

Output: DER/Data/14_Processed_90m/C4_ERP_proxy_90m.tif
"""

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.warp import reproject, Resampling
from rasterio.features import rasterize
from rasterstats import zonal_stats
from pathlib import Path
import os

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))  # raw data (Tier-2), override via env

EPPO_CSV    = BASE / "Energy map" / "EPPO_electricity_by_province_annual_2018_2025_long.csv"
GADM_GPKG   = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
WORLDPOP    = BASE / "DER" / "Data" / "05_Population" / "worldpop_THA_2020_100m.tif"
REF_GRID    = BASE / "Energy map" / "Thailand_DEM_90m.tif"
OUTPUT_DIR  = BASE / "DER" / "Data" / "14_Processed_90m"
OUTPUT_TIF  = OUTPUT_DIR / "C4_ERP_proxy_90m.tif"

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ── Constants ──────────────────────────────────────────────────────────────────
EF_EC       = 0.4682   # tCO2/MWh  (TGO EFEC 2022, announced May 2025)
EF_EC_kWh   = EF_EC / 1000.0   # tCO2/kWh
EPPO_YEAR   = 2022
NODATA_OUT  = -9999.0
PCTL_LO     = 2
PCTL_HI     = 98

# ── Step 1: Load EPPO electricity data ────────────────────────────────────────
print("Loading EPPO electricity data...")
eppo = pd.read_csv(EPPO_CSV)
eppo_2022 = eppo[eppo["Year"] == EPPO_YEAR][["GID_1", "Annual_Electricity_kWh"]].copy()
eppo_2022 = eppo_2022.dropna(subset=["Annual_Electricity_kWh"])
print(f"  Provinces with 2022 data: {len(eppo_2022)}")

# ── Step 2: Load province boundaries ──────────────────────────────────────────
print("Loading GADM province boundaries...")
import fiona
layers = fiona.listlayers(str(GADM_GPKG))
# Match layer ending with "_1" (province level) — avoids false match on "gadm41" prefix
adm1_layer = next((l for l in layers if l.endswith("_1")), None)
if adm1_layer is None:
    adm1_layer = layers[1]  # fallback: second layer by index
print(f"  Using layer: {adm1_layer}  (all layers: {layers})")

provinces = gpd.read_file(str(GADM_GPKG), layer=adm1_layer)
provinces = provinces[["GID_1", "geometry"]].copy()
print(f"  Provinces loaded: {len(provinces)}")

# ── Step 3: Zonal statistics — WorldPop sum per province ──────────────────────
print("Computing population per province (zonal stats)...")
with rasterio.open(str(WORLDPOP)) as _wp:
    wp_nodata = _wp.nodata if _wp.nodata is not None else -9999
print(f"  WorldPop nodata value: {wp_nodata}")
stats = zonal_stats(
    provinces,
    str(WORLDPOP),
    stats=["sum"],
    nodata=wp_nodata,
    all_touched=False,
)
provinces["pop_sum"] = [s["sum"] if s["sum"] is not None else 0 for s in stats]
print(f"  Total population (WorldPop): {provinces['pop_sum'].sum():,.0f}")

# ── Step 4: Join EPPO + compute per-capita electricity ────────────────────────
print("Computing per-capita electricity...")
provinces = provinces.merge(eppo_2022, on="GID_1", how="left")

missing = provinces["Annual_Electricity_kWh"].isna().sum()
if missing > 0:
    print(f"  WARNING: {missing} provinces missing EPPO 2022 data — filling with national mean")
    nat_mean = eppo_2022["Annual_Electricity_kWh"].mean()
    provinces["Annual_Electricity_kWh"] = provinces["Annual_Electricity_kWh"].fillna(nat_mean)

provinces["elec_per_capita"] = np.where(
    provinces["pop_sum"] > 0,
    provinces["Annual_Electricity_kWh"] / provinces["pop_sum"],
    0.0
)
print(f"  Per-capita range: {provinces['elec_per_capita'].min():.0f} – {provinces['elec_per_capita'].max():.0f} kWh/person/year")

# ── Step 5: Load reference grid metadata ──────────────────────────────────────
print("Reading reference grid...")
with rasterio.open(str(REF_GRID)) as ref:
    ref_transform = ref.transform
    ref_crs       = ref.crs
    ref_width     = ref.width
    ref_height    = ref.height
    ref_nodata    = ref.nodata if ref.nodata is not None else -9999
    ref_bounds    = ref.bounds

print(f"  Grid: {ref_width}x{ref_height}, CRS={ref_crs}")

# ── Step 6: Rasterize per-capita electricity (province-level) ─────────────────
print("Rasterizing per-capita electricity to 90m grid...")
if provinces.crs != ref_crs:
    provinces = provinces.to_crs(ref_crs)

shapes_elec = (
    (geom, val)
    for geom, val in zip(provinces.geometry, provinces["elec_per_capita"])
    if geom is not None and not pd.isna(val)
)

elec_raster = rasterize(
    shapes_elec,
    out_shape=(ref_height, ref_width),
    transform=ref_transform,
    fill=0.0,
    dtype="float32",
    all_touched=False,
)
print(f"  Rasterized elec_per_capita: min={elec_raster[elec_raster>0].min():.1f}, max={elec_raster.max():.1f} kWh/person")

# ── Step 7: Resample WorldPop to 90m reference grid ───────────────────────────
print("Resampling WorldPop to 90m reference grid...")
pop_90m = np.zeros((ref_height, ref_width), dtype="float32")

with rasterio.open(str(WORLDPOP)) as src:
    reproject(
        source=rasterio.band(src, 1),
        destination=pop_90m,
        src_transform=src.transform,
        src_crs=src.crs,
        dst_transform=ref_transform,
        dst_crs=ref_crs,
        resampling=Resampling.bilinear,
        src_nodata=src.nodata,
        dst_nodata=0.0,
    )

pop_90m = np.where(pop_90m < 0, 0.0, pop_90m)
print(f"  WorldPop 90m: max={pop_90m.max():.1f} persons/pixel")

# ── Step 8: Compute ERP ────────────────────────────────────────────────────────
print("Computing ERP...")
erp = pop_90m * elec_raster * EF_EC_kWh   # tCO2/pixel/year

# Convert persons/pixel to persons/km²
# At 90m resolution: pixel area ≈ 0.0081 km² (varies by latitude for geographic CRS)
# WorldPop is already in persons/pixel at 100m; after bilinear resample to 90m,
# values are approximately persons/pixel. Dividing by pixel area (km²) gives density.
PIXEL_AREA_KM2 = (90.0 / 1000.0) ** 2   # approximate for geographic CRS at mid-latitudes
erp_density = erp / PIXEL_AREA_KM2      # tCO2/km²/year

print(f"  ERP raw: max={erp_density[erp_density>0].max():.4f} tCO2/km2/yr")

# ── Step 9: Normalize to [0,1] using 2nd–98th percentile ─────────────────────
print("Normalizing ERP to [0,1]...")
valid = erp_density[erp_density > 0]
lo = np.percentile(valid, PCTL_LO)
hi = np.percentile(valid, PCTL_HI)
print(f"  Normalization range: [{lo:.6f}, {hi:.6f}] tCO2/km2/yr")

erp_norm = np.where(
    erp_density > 0,
    np.clip((erp_density - lo) / (hi - lo), 0.0, 1.0),
    NODATA_OUT,
)
erp_norm = erp_norm.astype("float32")

# ── Step 10: Write output ──────────────────────────────────────────────────────
print(f"Writing output: {OUTPUT_TIF}")
profile = {
    "driver":    "GTiff",
    "dtype":     "float32",
    "width":     ref_width,
    "height":    ref_height,
    "count":     1,
    "crs":       ref_crs,
    "transform": ref_transform,
    "nodata":    NODATA_OUT,
    "compress":  "lzw",
    "tiled":     True,
    "blockxsize": 512,
    "blockysize": 512,
}

with rasterio.open(str(OUTPUT_TIF), "w", **profile) as dst:
    dst.write(erp_norm, 1)
    dst.update_tags(
        description="C4 proxy: Emission Reduction Potential (ERP)",
        formula="pop_density x elec_per_capita_province x EFEC",
        EFEC_tCO2_per_MWh="0.4682",
        EFEC_year="2022",
        EFEC_source="TGO, announced 28 May B.E. 2568 (2025)",
        elec_data="EPPO 2022",
        pop_data="WorldPop 2020 100m UN-adjusted",
        normalization=f"min-max 2nd-98th percentile: [{lo:.6f}, {hi:.6f}]",
        nodata_value=str(NODATA_OUT),
        created="2026-07-07",
    )

print("\nDone.")
print(f"  Output: {OUTPUT_TIF}")
print(f"  Normalization range: {lo:.6f} – {hi:.6f} tCO2/km2/yr")
print(f"  Valid pixels (ERP>0): {(erp_norm != NODATA_OUT).sum():,}")
