# -*- coding: utf-8 -*-
"""
Compute nDSM (normalized Digital Surface Model) = ALOS AW3D30 DSM - Copernicus DEM,
then mask out vegetation using Hansen treecover2000 to isolate building height.

Prerequisites:
  1. Run GEE script alos_aw3d30_export.js and download the output to Energy map\
  2. Thailand_DEM_90m.tif and Thailand_forest_treecover2000_90m.tif already present

Outputs (all in Energy map\):
  Thailand_nDSM_raw_90m.tif          -- raw above-ground height (buildings + vegetation)
  Thailand_building_height_nDSM_90m.tif -- vegetation-masked, buildings only (proxy)

Methodology note:
  Both ALOS AW3D30 and Copernicus GLO-30 are DSMs (capture above-ground surfaces).
  Their difference amplifies structures that ALOS resolves at 30m but Copernicus
  smooths at the same effective scale. The result is a coarse building-height proxy;
  Google Open Buildings 2.5D (0.5m native) remains the primary building layer.
  This file serves as independent cross-validation and gap-filler for areas where
  Open Buildings has low confidence.
"""

import numpy as np
import rasterio
from rasterio.warp import reproject, Resampling
from pathlib import Path

DATA_DIR = Path(r"D:\Clude Code GIS\Energy\Energy map")

ALOS_PATH      = DATA_DIR / "Thailand_ALOS_AW3D30_DSM_90m.tif"
DEM_PATH       = DATA_DIR / "Thailand_DEM_90m.tif"
TREECOVER_PATH = DATA_DIR / "Thailand_forest_treecover2000_90m.tif"

OUT_RAW        = DATA_DIR / "Thailand_nDSM_raw_90m.tif"
OUT_BUILDINGS  = DATA_DIR / "Thailand_building_height_nDSM_90m.tif"

TREE_THRESHOLD = 30   # Hansen treecover % -- pixels >= this are treated as forest/vegetation
MAX_HEIGHT_M   = 200  # clip ceiling (tallest building in Thailand ~310m but 200m covers >99%)
NODATA_OUT     = -9999.0


def align_to_reference(src_path, ref_profile):
    """Reproject/resample src raster to exactly match ref_profile grid."""
    h = ref_profile['height']
    w = ref_profile['width']
    out = np.empty((h, w), dtype=np.float32)
    with rasterio.open(src_path) as src:
        reproject(
            source=rasterio.band(src, 1),
            destination=out,
            src_transform=src.transform,
            src_crs=src.crs,
            dst_transform=ref_profile['transform'],
            dst_crs=ref_profile['crs'],
            resampling=Resampling.bilinear,
            src_nodata=src.nodata,
            dst_nodata=NODATA_OUT,
        )
    return out


def write_tif(path, data, profile, nodata=NODATA_OUT):
    prof = profile.copy()
    prof.update(dtype='float32', count=1, nodata=nodata, compress='lzw', predictor=2)
    with rasterio.open(path, 'w', **prof) as dst:
        dst.write(data.astype(np.float32), 1)
    print(f"  Wrote: {path.name}  ({data[data != nodata].shape[0]:,} valid pixels)")


def main():
    if not ALOS_PATH.exists():
        raise FileNotFoundError(
            f"ALOS DSM not found: {ALOS_PATH}\n"
            "Run GEE script alos_aw3d30_export.js first and download the .tif to Energy map\\"
        )

    print("Loading Copernicus DEM (reference grid)...")
    with rasterio.open(DEM_PATH) as dem_ds:
        dem_data = dem_ds.read(1, masked=True).astype(np.float32)
        ref_profile = dem_ds.profile
        dem_nodata = dem_ds.nodata if dem_ds.nodata is not None else -9999.0

    print("Aligning ALOS DSM to DEM grid...")
    alos_data = align_to_reference(ALOS_PATH, ref_profile)

    print("Computing nDSM = ALOS DSM - Copernicus DEM...")
    dem_arr = dem_data.filled(np.nan) if hasattr(dem_data, 'filled') else dem_data.data

    valid_mask = (alos_data != NODATA_OUT) & (~np.isnan(dem_arr))
    ndsm = np.full_like(alos_data, NODATA_OUT)
    ndsm[valid_mask] = alos_data[valid_mask] - dem_arr[valid_mask]

    # Clamp: negative values = terrain noise (DEM lower than DSM is impossible physically)
    ndsm[valid_mask] = np.clip(ndsm[valid_mask], 0, MAX_HEIGHT_M)

    print(f"  nDSM stats (valid pixels): "
          f"min={ndsm[valid_mask].min():.1f}m  "
          f"mean={ndsm[valid_mask].mean():.1f}m  "
          f"max={ndsm[valid_mask].max():.1f}m")

    write_tif(OUT_RAW, ndsm, ref_profile)

    print(f"Applying Hansen treecover mask (threshold >= {TREE_THRESHOLD}%)...")
    tc_data = align_to_reference(TREECOVER_PATH, ref_profile)

    building_height = ndsm.copy()
    # Pixels with high tree cover are forest/vegetation, not buildings
    veg_mask = valid_mask & (tc_data >= TREE_THRESHOLD)
    building_height[veg_mask] = 0.0

    masked_valid = valid_mask & (building_height > 0)
    print(f"  Pixels with building height > 0: {masked_valid.sum():,} "
          f"({masked_valid.sum() / valid_mask.sum() * 100:.1f}% of valid area)")

    write_tif(OUT_BUILDINGS, building_height, ref_profile)

    print("\nDone.")
    print(f"  Raw nDSM (ป่า+อาคาร): {OUT_RAW.name}")
    print(f"  Building height proxy: {OUT_BUILDINGS.name}")
    print()
    print("Interpretation notes:")
    print("  - This is a coarse proxy (~90m), not a per-building measurement.")
    print("  - Compare against Google Open Buildings 2.5D for cross-validation.")
    print("  - Forest pixels set to 0, not NoData -- use raw file if forest height needed.")
    print(f"  - Hansen treecover threshold used: {TREE_THRESHOLD}% (year 2000 baseline).")


if __name__ == '__main__':
    main()
