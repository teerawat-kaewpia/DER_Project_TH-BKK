# -*- coding: utf-8 -*-
"""
Rasterize the VALID province equity criterion (NESDC poverty incidence) to the
90 m reference grid, replacing the NTL-based C2.

C2_poverty = linear [0,1] normalisation of provincial poverty incidence (%),
2nd-98th percentile clip, benefit direction (high poverty -> high DER priority) —
matching the framework's stated normalisation (Table 1). Each province's pixels
carry its normalised value (province-constant, like the original C2 raster).

Input : C2_poverty_province.csv (77 provinces) + GADM ADM1 + DEM ref grid
Output: DER/Data/14_Processed_90m/C2_poverty_90m.tif   (float32 [0,1])
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterio.features import rasterize
from pathlib import Path
import os
import fiona

BASE   = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))
PROC   = BASE / "DER" / "Data" / "14_Processed_90m"
GADM   = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
REF    = BASE / "Energy map" / "Thailand_DEM_90m.tif"
POVCSV = PROC / "C2_poverty_province.csv"
OUT    = PROC / "C2_poverty_90m.tif"
NODATA = -9999.0

# ── reference grid ─────────────────────────────────────────────────────────────
with rasterio.open(REF) as ref:
    tr, crs, W, H = ref.transform, ref.crs, ref.width, ref.height
print(f"Ref grid: {W}x{H}, {crs}")

# ── province poverty + normalise [0,1] (2-98 pct clip, benefit) ───────────────
pov = pd.read_csv(POVCSV)
v = pov["poverty_pct"].to_numpy(float)
lo, hi = np.nanpercentile(v, 2), np.nanpercentile(v, 98)
pov["C2"] = np.clip((v - lo) / (hi - lo + 1e-12), 0.0, 1.0)
print(f"poverty_pct [{v.min():.2f}, {v.max():.2f}] -> C2 norm [0,1] "
      f"(2nd pct={lo:.2f}, 98th pct={hi:.2f})")
print(f"  C2 mean={pov['C2'].mean():.3f}  CV={100*pov['C2'].std()/pov['C2'].mean():.1f}%")

# ── join to geometry ───────────────────────────────────────────────────────────
adm1 = next(l for l in fiona.listlayers(str(GADM)) if l.endswith("_1"))
g = gpd.read_file(str(GADM), layer=adm1)[["NAME_1", "geometry"]]
if g.crs != crs:
    g = g.to_crs(crs)
g = g.merge(pov[["NAME_1", "C2"]], on="NAME_1", how="left")
print(f"Joined {g['C2'].notna().sum()}/77 provinces")

# ── rasterize ──────────────────────────────────────────────────────────────────
shapes = ((geom, val) for geom, val in zip(g.geometry, g["C2"])
          if geom is not None and not pd.isna(val))
c2 = rasterize(shapes, out_shape=(H, W), transform=tr, fill=NODATA,
               dtype="float32", all_touched=False)

profile = {"driver": "GTiff", "dtype": "float32", "width": W, "height": H,
           "count": 1, "crs": crs, "transform": tr, "nodata": NODATA,
           "compress": "lzw", "tiled": True, "blockxsize": 512, "blockysize": 512}
with rasterio.open(OUT, "w", **profile) as dst:
    dst.write(c2, 1)
    dst.update_tags(
        description="C2 Equity — provincial poverty incidence (NESDC), normalised [0,1]",
        formula="linear [0,1] of poverty incidence %, 2nd-98th pct clip, benefit",
        source="NESDC Poverty & Income Distribution 2567, Table 1.5 (NSO SES)",
        replaces="C2_energy_poverty_90m.tif (inverted NTL/capita)",
    )
print(f"\nDone. Valid pixels: {(c2 != NODATA).sum():,}")
print(f"Saved: {OUT}")
