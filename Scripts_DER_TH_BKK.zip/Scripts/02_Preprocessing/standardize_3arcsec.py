
"""
Standardize all raster layers to 3 arc-second (~90m)
Thailand bounding box: [97.5, 5.5, 105.7, 20.5]
"""
from pathlib import Path
import subprocess

BASE = Path(r'D:\Clude Code GIS\Energy\DER\Data')
OUT  = Path(r'D:\Clude Code GIS\Energy\DER\Data\14_Processed_90m')
BBOX = '97.5 5.5 105.7 20.5'
RES  = '0.000833333'  # 3 arc-second in decimal degrees

LAYERS = [
    # (input_path, output_name, resample_method)
    ('02_Solar_Resource/GHI_Thailand.tif',          'solar_GHI_90m.tif',        'bilinear'),
    ('03_Wind_Resource/wind_speed_100m.tif',         'wind_speed_90m.tif',        'bilinear'),
    ('04_Land_Use_LULC/ESA_WorldCover_2021_10m.tif','lulc_worldcover_90m.tif',   'mode'),
    ('05_Population/worldpop_THA_2020_1km.tif',      'population_90m.tif',        'bilinear'),
    ('06_Night_Lights/VIIRS_NTL_2022.tif',           'viirs_ntl_90m.tif',         'bilinear'),
    ('07_Buildings/GoogleOB_height_2023.tif',        'building_height_90m.tif',   'average'),
    ('08_DEM_Terrain/CopernicusDEM_30m.tif',         'dem_elevation_90m.tif',     'bilinear'),
    ('09_Forest_Carbon/Hansen_treecover2000.tif',    'forest_cover_90m.tif',      'average'),
]

for src_rel, out_name, method in LAYERS:
    src = BASE / src_rel
    dst = OUT / out_name
    if not src.exists():
        print(f'⚠ Skip (not found): {src.name}')
        continue
    cmd = (f'gdalwarp -t_srs EPSG:4326 -tr {RES} {RES} '
           f'-te {BBOX} -r {method} -of GTiff '
           f'-co COMPRESS=LZW -co TILED=YES '
           f'"{src}" "{dst}"')
    print(f'→ Processing: {out_name}')
    result = subprocess.run(cmd, shell=True, capture_output=True)
    if result.returncode == 0:
        print(f'  ✓ Done: {out_name}')
    else:
        print(f'  ✗ Error: {result.stderr.decode()[:200]}')
