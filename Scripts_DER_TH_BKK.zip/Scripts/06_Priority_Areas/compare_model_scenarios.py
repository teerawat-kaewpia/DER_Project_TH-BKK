"""
4-scenario comparison: C5 inflation fix + VIF multicollinearity solutions
==========================================================================
S0  Baseline   : C1, C2, C3, C4_NTL, C5_GridFinder, C6   (current, all problems)
S1  C5-fix     : C1, C2, C3, C4_NTL, C5_distance,   C6   (fix weight inflation only)
S2  Drop-C4    : C1, C2, C3,          C5_distance,   C6   (remove redundant ERP)
S3  Merge-DI   : C1, C2, DI=(C3+C4)/2, C5_distance, C6   (merge demand intensity)

For each scenario: EWM weights, VIF, TOPSIS PAI, province ranking, Spearman vs S0.
"""

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterstats import zonal_stats
from scipy.stats import spearmanr
from numpy.linalg import inv, LinAlgError
from pathlib import Path
import os
import fiona
import warnings
warnings.filterwarnings("ignore")

BASE   = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))
PROC   = BASE / "DER" / "Data" / "14_Processed_90m"
GADM   = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
NODATA = -9999.0

# ── Load all 7 input layers ────────────────────────────────────────────────────
print("Loading criteria layers...")
LAYER_FILES = {
    "C1":    PROC / "C1_PVOUT_90m.tif",
    "C2":    PROC / "C2_energy_poverty_90m.tif",
    "C3":    PROC / "C3_popdens_90m.tif",
    "C4":    PROC / "C4_ERP_proxy_NTL_90m.tif",
    "C5_gf": PROC / "C5_grid_access_90m.tif",       # GridFinder (current)
    "C5_d":  PROC / "C5_grid_dist_90m.tif",          # distance-based (new)
    "C6":    PROC / "C6_land_suitability_90m.tif",
}
arrays, nd_vals = {}, {}
for name, path in LAYER_FILES.items():
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float32")
        nd  = np.float32(src.nodata if src.nodata is not None else -9999)
        tfm, crs, W, H = src.transform, src.crs, src.width, src.height
    arrays[name], nd_vals[name] = arr, nd
    valid = arr[arr != nd]
    print(f"  {name}: {(arr != nd).sum():,} valid | range [{valid.min():.4f},{valid.max():.4f}]")

# Land mask = union of all layers
land_mask = np.ones((H, W), dtype=bool)
for name, arr in arrays.items():
    land_mask &= (arr != nd_vals[name])
n_pix = land_mask.sum()
print(f"  Unified land pixels: {n_pix:,}")

# ── Define 4 scenarios ────────────────────────────────────────────────────────
def make_X(crit_names):
    """Extract pixel matrix [n_pix x n_crit] for given criterion list."""
    cols = []
    for c in crit_names:
        vals = arrays[c][land_mask]
        # DI = mean(C3, C4) already handled below
        cols.append(vals)
    return np.stack(cols, axis=1).astype("float32")

# Demand Intensity = (C3 + C4) / 2, clipped to [0,1]
di = np.clip((arrays["C3"] + arrays["C4"]) / 2.0, 0.0, 1.0)
arrays["DI"] = di; nd_vals["DI"] = np.float32(NODATA)

SCENARIOS = {
    "S0_Baseline": ["C1","C2","C3","C4","C5_gf","C6"],
    "S1_C5fix":    ["C1","C2","C3","C4","C5_d", "C6"],
    "S2_DropC4":   ["C1","C2","C3",    "C5_d", "C6"],
    "S3_MergeDI":  ["C1","C2","DI",    "C5_d", "C6"],
}
LABELS = {
    "S0_Baseline": "S0 Baseline (GridFinder C5, with C4)",
    "S1_C5fix":    "S1 C5-fixed (distance C5, keep C4)",
    "S2_DropC4":   "S2 Drop C4 (distance C5, no C4)",
    "S3_MergeDI":  "S3 Merge DI (distance C5, C3+C4→DI)",
}

# ── Helper functions ──────────────────────────────────────────────────────────
def ewm_weights(X):
    n = X.shape[0]
    X_pos = X - X.min(axis=0) + 1e-6
    col_sum = X_pos.sum(axis=0)
    P = X_pos / col_sum
    ln_n = np.log(n)
    with np.errstate(divide="ignore", invalid="ignore"):
        lnP = np.where(P > 0, np.log(P), 0.0)
    e = np.clip(-(1.0/ln_n) * (P * lnP).sum(axis=0), 0.0, 1.0)
    d = 1.0 - e
    w = d / d.sum()
    return w, e, d

def topsis(X, w):
    Xw = X * w
    Ap = Xw.max(axis=0); An = Xw.min(axis=0)
    Dp = np.sqrt(((Xw - Ap)**2).sum(axis=1))
    Dn = np.sqrt(((Xw - An)**2).sum(axis=1))
    return (Dn / (Dp + Dn + 1e-12)).astype("float32")

def vif(X, names):
    result = {}
    for i, name in enumerate(names):
        y  = X[:, i]
        Xo = np.delete(X, i, axis=1)
        Xo = np.column_stack([np.ones(len(Xo)), Xo])
        try:
            beta = inv(Xo.T @ Xo) @ Xo.T @ y
            yhat = Xo @ beta
            ss_r = ((y - yhat)**2).sum(); ss_t = ((y - y.mean())**2).sum()
            r2 = 1 - ss_r/ss_t if ss_t > 0 else 0
            v = 1/(1-r2) if r2 < 1 else 999.0
        except LinAlgError:
            v = 999.0
        result[name] = round(v, 2)
    return result

# ── Province geometries ────────────────────────────────────────────────────────
layers = fiona.listlayers(str(GADM))
adm1 = next((l for l in layers if l.endswith("_1")), layers[1])
prov = gpd.read_file(str(GADM), layer=adm1)[["GID_1","NAME_1","geometry"]].copy()
if prov.crs.to_epsg() != 4326:
    prov = prov.to_crs("EPSG:4326")

# ── Run all scenarios ─────────────────────────────────────────────────────────
results = {}   # scenario → dict of arrays, weights, vif, province PAI
PAI_grids = {}

print("\nRunning EWM + TOPSIS for each scenario...")
for sname, crit_list in SCENARIOS.items():
    print(f"\n{'='*60}")
    print(f"  {LABELS[sname]}")
    print(f"  Criteria: {crit_list}")

    # Subsample for VIF (RAM efficient)
    rng = np.random.default_rng(42)
    idx_sub = rng.choice(n_pix, size=min(300_000, n_pix), replace=False)

    X_full = np.zeros((n_pix, len(crit_list)), dtype="float32")
    for j, c in enumerate(crit_list):
        X_full[:, j] = arrays[c][land_mask]

    X_sub  = X_full[idx_sub]

    # EWM
    w, e, d = ewm_weights(X_full)
    print(f"\n  EWM Weights:")
    for c, wi, ei in zip(crit_list, w, e):
        bar = "#" * int(wi * 100)
        flag = " *** HIGH" if wi > 0.22 else ""
        print(f"    {c:8s}: w={wi:.4f} ({wi*100:5.1f}%)  e={ei:.4f}  {bar}{flag}")

    # VIF (on subsample)
    vif_d = vif(X_sub, crit_list)
    print(f"\n  VIF (subsample n=300K):")
    for c, v in vif_d.items():
        flag = " ***SEVERE" if v > 10 else (" *moderate" if v > 5 else "")
        print(f"    {c:8s}: {v:7.2f}{flag}")

    # TOPSIS PAI
    PAI_vals = topsis(X_full, w)
    print(f"\n  PAI: [{PAI_vals.min():.4f}, {PAI_vals.max():.4f}] | mean={PAI_vals.mean():.4f}")

    # Rasterize PAI → province zonal stats
    pai_grid = np.full((H, W), NODATA, dtype="float32")
    pai_grid[land_mask] = PAI_vals
    stats = zonal_stats(prov, pai_grid, affine=tfm, stats=["mean"], nodata=NODATA)
    prov_pai = [s["mean"] if s["mean"] is not None else np.nan for s in stats]

    results[sname] = {
        "weights": dict(zip(crit_list, w)),
        "entropy": dict(zip(crit_list, e)),
        "vif": vif_d,
        "PAI_vals": PAI_vals,
        "prov_pai": prov_pai,
    }
    PAI_grids[sname] = pai_grid

# ── Province ranking comparison ────────────────────────────────────────────────
print("\n" + "="*70)
print("PROVINCE RANKING COMPARISON")
print("="*70)

prov_df = prov[["GID_1","NAME_1"]].copy()
for sname in SCENARIOS:
    prov_df[f"PAI_{sname}"] = results[sname]["prov_pai"]
    prov_df[f"rank_{sname}"] = prov_df[f"PAI_{sname}"].rank(ascending=False).astype(int)

# Spearman correlations vs S0
print("\nSpearman rank correlation vs S0_Baseline:")
for sname in list(SCENARIOS.keys())[1:]:
    rho, p = spearmanr(prov_df["PAI_S0_Baseline"], prov_df[f"PAI_{sname}"])
    print(f"  S0 vs {sname}: rho={rho:.4f}  p={p:.4f}")

# Top 10 province rankings comparison
print("\nTop 10 provinces by S0 rank — all scenario rankings:")
top10_idx = prov_df.nsmallest(10, "rank_S0_Baseline").index
rank_cols  = [f"rank_{s}" for s in SCENARIOS]
pai_cols   = [f"PAI_{s}" for s in SCENARIOS]
top10 = prov_df.loc[top10_idx, ["NAME_1"] + rank_cols].copy()
top10.columns = ["Province","S0","S1","S2","S3"]
top10["S1_shift"] = top10["S1"] - top10["S0"]
top10["S2_shift"] = top10["S2"] - top10["S0"]
top10["S3_shift"] = top10["S3"] - top10["S0"]
print(top10.to_string(index=False))

# Provinces with largest rank shifts S0→S2 (Drop C4)
print("\nLargest rank shifts: S0_Baseline vs S2_DropC4 (VIF fix effect):")
prov_df["shift_S2"] = (prov_df["rank_S2_DropC4"] - prov_df["rank_S0_Baseline"]).abs()
big_shift = prov_df.nlargest(10, "shift_S2")[["NAME_1","rank_S0_Baseline","rank_S2_DropC4","shift_S2",
                                               "PAI_S0_Baseline","PAI_S2_DropC4"]]
print(big_shift.to_string(index=False))

# ── EWM weight summary table ───────────────────────────────────────────────────
print("\n" + "="*70)
print("EWM WEIGHT SUMMARY (all scenarios)")
print("="*70)
all_crits = ["C1","C2","C3","C4","DI","C5_gf","C5_d","C6"]
weight_table = {}
for sname, res in results.items():
    weight_table[sname] = {c: res["weights"].get(c, np.nan) for c in all_crits}
wt_df = pd.DataFrame(weight_table, index=all_crits).round(4)
wt_df.columns = ["S0_Baseline","S1_C5fix","S2_DropC4","S3_MergeDI"]
print(wt_df.dropna(how="all").to_string())

# ── Save comparison CSV ────────────────────────────────────────────────────────
out_csv = PROC / "scenario_comparison.csv"
save_cols = ["GID_1","NAME_1"] + [f"PAI_{s}" for s in SCENARIOS] + [f"rank_{s}" for s in SCENARIOS]
prov_df[save_cols].to_csv(out_csv, index=False, encoding="utf-8-sig")
print(f"\nSaved: {out_csv}")

# Save S2 PAI raster (recommended model)
s2_out = PROC / "PAI_S2_DropC4_90m.tif"
profile = {"driver":"GTiff","dtype":"float32","width":W,"height":H,"count":1,
           "crs":crs,"transform":tfm,"nodata":NODATA,"compress":"lzw",
           "tiled":True,"blockxsize":512,"blockysize":512}
with rasterio.open(s2_out, "w", **profile) as dst:
    dst.write(PAI_grids["S2_DropC4"], 1)
    dst.update_tags(description="PAI S2: C1,C2,C3,C5_distance,C6 (Drop C4, distance C5)")
print(f"S2 PAI raster saved: {s2_out}")

s3_out = PROC / "PAI_S3_MergeDI_90m.tif"
with rasterio.open(s3_out, "w", **profile) as dst:
    dst.write(PAI_grids["S3_MergeDI"], 1)
    dst.update_tags(description="PAI S3: C1,C2,DI=(C3+C4)/2,C5_distance,C6")
print(f"S3 PAI raster saved: {s3_out}")
