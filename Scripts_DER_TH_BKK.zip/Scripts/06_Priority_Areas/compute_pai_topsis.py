"""
DER Priority Area Index (PAI) — EWM + TOPSIS + K-means clustering
===================================================================
Final model S2: 5 criteria (C4_ERP dropped — redundant with C3, collinear with C2)

Stage 1 — Entropy Weight Method (EWM): derive objective weights for C1–C5
Stage 2 — TOPSIS: compute PAI surface [0,1] over Thailand at 90m
Stage 3 — K-means: classify PAI into 5 DER priority zones

Criteria (all normalized [0,1], higher = more beneficial):
  C1  Solar Potential    PVOUT (kWh/kWp/yr) from Global Solar Atlas
  C2  Energy Poverty     Inverse NTL per capita → high score = high poverty
  C3  Population Density WorldPop 2020 — demand potential
  C4  Grid Accessibility exp(-dist_km/5) from OSM power lines — connectivity
  C5  Land Suitability   Forest + slope + urban override (GHSL)

Rationale for S2 (Drop C4_ERP):
  - C3 already captures demand; NTL-proxy C4 was redundant (province VIF=24.98)
  - C4 conflicted with C2 (both NTL-derived, inverse relationship, r=−0.454)
  - C4_grid_dist replaces GridFinder C5 (fixes 93.6%→13.9% zero-inflation in EWM)
  - 5 criteria cover: resource / social need / demand / connectivity / feasibility

Input  : DER/Data/14_Processed_90m/C1–C6 rasters (9600×18000, EPSG:4326)
         Source files: C1_PVOUT, C2_energy_poverty, C3_popdens,
                       C5_grid_dist (→ C4), C6_land_suitability (→ C5)
Output : DER/Data/14_Processed_90m/PAI_90m.tif        (float32 [0,1])
         DER/Data/14_Processed_90m/DER_zones_90m.tif  (uint8, zones 1–5)
         DER/Data/14_Processed_90m/EWM_weights.csv    (criterion weights)
"""

import numpy as np
import rasterio
import pandas as pd
from sklearn.cluster import MiniBatchKMeans
from pathlib import Path
import os

BASE      = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))
PROC      = BASE / "DER" / "Data" / "14_Processed_90m"
REF_GRID  = BASE / "Energy map" / "Thailand_DEM_90m.tif"

CRITERIA = {
    "C1_Solar":    PROC / "C1_PVOUT_90m.tif",
    "C2_Poverty":  PROC / "C2_energy_poverty_90m.tif",
    "C3_PopDens":  PROC / "C3_popdens_90m.tif",
    "C4_GridDist": PROC / "C5_grid_dist_90m.tif",       # distance-based (exp decay); source file = C5
    "C5_LandSuit": PROC / "C6_land_suitability_90m.tif", # source file = C6
}
N_ZONES   = 5
NODATA_OUT = -9999.0

# ── Read reference grid ────────────────────────────────────────────────────────
with rasterio.open(REF_GRID) as ref:
    ref_transform = ref.transform
    ref_crs       = ref.crs
    ref_width     = ref.width
    ref_height    = ref.height

# ── Load all criteria layers ───────────────────────────────────────────────────
print("Loading criteria layers...")
arrays = {}
nodata_vals = {}
for name, path in CRITERIA.items():
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float32")
        nd  = src.nodata if src.nodata is not None else -9999.0
    arrays[name] = arr
    nodata_vals[name] = np.float32(nd)
    valid = arr[arr != np.float32(nd)]
    print(f"  {name}: {(arr != np.float32(nd)).sum():,} valid | range [{valid.min():.4f}, {valid.max():.4f}]")

# ── Build unified land mask (pixels valid in ALL criteria) ────────────────────
print("\nBuilding unified land mask...")
land_mask = np.ones((ref_height, ref_width), dtype=bool)
for name, arr in arrays.items():
    land_mask &= (arr != nodata_vals[name])
print(f"  Unified land pixels: {land_mask.sum():,}")

# ── Extract pixel matrix X [n_pixels x n_criteria] ────────────────────────────
n_pix   = land_mask.sum()
n_crit  = len(CRITERIA)
names   = list(CRITERIA.keys())

X = np.zeros((n_pix, n_crit), dtype="float32")
for j, name in enumerate(names):
    X[:, j] = arrays[name][land_mask]

# ── Stage 1: Entropy Weight Method (EWM) ──────────────────────────────────────
print("\nStage 1 — EWM weight calculation...")

# Shift all values to strictly positive (avoid log(0))
X_pos = X - X.min(axis=0) + 1e-6

# Normalize: p_ij = x_ij / sum_j(x_ij)
col_sum = X_pos.sum(axis=0)
P = X_pos / col_sum[np.newaxis, :]

# Entropy: e_j = -1/ln(n) * sum_i(p_ij * ln(p_ij))
ln_n = np.log(n_pix)
with np.errstate(divide="ignore", invalid="ignore"):
    lnP = np.where(P > 0, np.log(P), 0.0)
e = -(1.0 / ln_n) * (P * lnP).sum(axis=0)
e = np.clip(e, 0.0, 1.0)

# Divergence d_j = 1 - e_j
d = 1.0 - e

# Weight w_j = d_j / sum(d)
w = d / d.sum()

weights_df = pd.DataFrame({"criterion": names, "entropy": e, "divergence": d, "weight": w})
print(weights_df.to_string(index=False))

weights_out = PROC / "EWM_weights.csv"
weights_df.to_csv(weights_out, index=False)
print(f"\n  Weights saved: {weights_out}")

# ── Stage 2: TOPSIS ────────────────────────────────────────────────────────────
print("\nStage 2 — TOPSIS...")

# Weighted normalized decision matrix
# All criteria are benefit (+): higher = better
X_weighted = X * w[np.newaxis, :]

# Theoretical ideal best (A+) and worst (A-) based on normalized [0,1] criterion range.
# All criteria were preprocessed to [0,1], so theoretical bounds are w (max=1.0) and 0.
# Using theoretical rather than empirical bounds ensures criteria like C2 (effective max
# < 1.0 due to national-mean formula) contribute proportionally to their EWM weight.
A_pos = w.copy()          # theoretical max: each criterion at 1.0 → weighted = w
A_neg = np.zeros(n_crit)  # theoretical min: each criterion at 0.0
print(f"  A+ (theoretical): {A_pos.round(4)}")
print(f"  A- (theoretical): {A_neg.round(4)}")
print(f"  Empirical max:    {X_weighted.max(axis=0).round(4)}  (C2 effective max < w[C2])")

# Euclidean distances to ideal solutions
D_pos = np.sqrt(((X_weighted - A_pos[np.newaxis, :]) ** 2).sum(axis=1))
D_neg = np.sqrt(((X_weighted - A_neg[np.newaxis, :]) ** 2).sum(axis=1))

# Closeness coefficient (PAI)
PAI = D_neg / (D_pos + D_neg + 1e-12)
PAI = PAI.astype("float32")
print(f"  PAI range: {PAI.min():.4f} – {PAI.max():.4f} | mean: {PAI.mean():.4f}")

# ── Stage 3: K-means zone classification ──────────────────────────────────────
print(f"\nStage 3 — K-means clustering into {N_ZONES} zones...")
km = MiniBatchKMeans(n_clusters=N_ZONES, random_state=42, n_init=10, batch_size=100_000)
zone_labels = km.fit_predict(PAI.reshape(-1, 1))

# Re-label so zone 1 = highest PAI, zone N = lowest
zone_means = [PAI[zone_labels == z].mean() for z in range(N_ZONES)]
rank_map = {orig: rank + 1 for rank, orig in enumerate(np.argsort(zone_means)[::-1])}
zone_ranked = np.array([rank_map[z] for z in zone_labels], dtype=np.uint8)

for z in range(1, N_ZONES + 1):
    mask_z = zone_ranked == z
    print(f"  Zone {z}: {mask_z.sum():,} px | PAI mean={PAI[mask_z].mean():.4f} [{PAI[mask_z].min():.4f}–{PAI[mask_z].max():.4f}]")

# ── Write PAI raster ───────────────────────────────────────────────────────────
pai_grid = np.full((ref_height, ref_width), NODATA_OUT, dtype="float32")
pai_grid[land_mask] = PAI
profile_f = {
    "driver": "GTiff", "dtype": "float32",
    "width": ref_width, "height": ref_height, "count": 1,
    "crs": ref_crs, "transform": ref_transform,
    "nodata": NODATA_OUT, "compress": "lzw",
    "tiled": True, "blockxsize": 512, "blockysize": 512,
}
pai_out = PROC / "PAI_90m.tif"
print(f"\nWriting PAI: {pai_out}")
with rasterio.open(pai_out, "w", **profile_f) as dst:
    dst.write(pai_grid, 1)
    dst.update_tags(
        description="DER Priority Area Index (PAI) via EWM+TOPSIS — S2 final model",
        criteria="C1_Solar,C2_Poverty,C3_PopDens,C4_GridDist,C5_LandSuit",
        weights=",".join(f"{x:.4f}" for x in w),
        model="S2_DropC4ERP_DistanceC4",
        created="2026-07-07",
    )

# ── Write zone raster ──────────────────────────────────────────────────────────
zone_grid = np.zeros((ref_height, ref_width), dtype=np.uint8)
zone_grid[land_mask] = zone_ranked
profile_u = {**profile_f, "dtype": "uint8", "nodata": 0}
zone_out = PROC / "DER_zones_90m.tif"
print(f"Writing zones: {zone_out}")
with rasterio.open(zone_out, "w", **profile_u) as dst:
    dst.write(zone_grid, 1)
    dst.update_tags(
        description="DER Priority Zones 1–5 (1=highest, 5=lowest) via K-means on PAI",
        zone_count=str(N_ZONES),
        created="2026-07-07",
    )

print("\n=== COMPLETE ===")
print(f"  PAI:   {pai_out}")
print(f"  Zones: {zone_out}")
print(f"  EWM weights: {weights_out}")
print(f"\nEWM weights summary:")
for _, row in weights_df.iterrows():
    print(f"  {row['criterion']}: {row['weight']:.4f} ({row['weight']*100:.1f}%)")
