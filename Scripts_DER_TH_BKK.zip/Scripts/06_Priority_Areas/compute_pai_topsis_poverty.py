# -*- coding: utf-8 -*-
"""
Province PAI rerun with VALID equity criterion (poverty incidence) replacing
inverted NTL/capita. Pixel-level EWM + TOPSIS + K-means, identical to
compute_pai_topsis.py except C2 and the output names. Prints an NTL-vs-poverty
comparison of EWM weights and PAI.

Output: PAI_poverty_90m.tif, DER_zones_poverty_90m.tif, EWM_weights_poverty.csv
"""
import numpy as np
import rasterio
import pandas as pd
from sklearn.cluster import MiniBatchKMeans
from pathlib import Path
import os

BASE = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))  # raw data (Tier-2), override via env
PROC = BASE / "DER" / "Data" / "14_Processed_90m"

CRITERIA = {
    "C1_Solar":    PROC / "C1_PVOUT_90m.tif",
    "C2_Poverty":  PROC / "C2_poverty_90m.tif",        # <-- was C2_energy_poverty (NTL)
    "C3_PopDens":  PROC / "C3_popdens_90m.tif",
    "C4_GridDist": PROC / "C5_grid_dist_90m.tif",
    "C5_LandSuit": PROC / "C6_land_suitability_90m.tif",
}
N_ZONES = 5
NODATA_OUT = -9999.0

with rasterio.open(BASE / "Energy map" / "Thailand_DEM_90m.tif") as ref:
    ref_transform, ref_crs = ref.transform, ref.crs
    ref_width, ref_height = ref.width, ref.height

print("Loading criteria...")
arrays, nod = {}, {}
for name, path in CRITERIA.items():
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float32")
        nd = np.float32(src.nodata if src.nodata is not None else -9999.0)
    arrays[name], nod[name] = arr, nd
    valid = arr[arr != nd]
    print(f"  {name}: {(arr!=nd).sum():,} valid | [{valid.min():.4f}, {valid.max():.4f}]")

land = np.ones((ref_height, ref_width), dtype=bool)
for name, arr in arrays.items():
    land &= (arr != nod[name])
print(f"Unified land pixels: {land.sum():,}")

names = list(CRITERIA.keys())
X = np.column_stack([arrays[n][land] for n in names]).astype("float32")
n_pix = X.shape[0]

# ── EWM ────────────────────────────────────────────────────────────────────────
Xp = X - X.min(0) + 1e-6
P = Xp / Xp.sum(0, keepdims=True)
ln_n = np.log(n_pix)
with np.errstate(divide="ignore", invalid="ignore"):
    lnP = np.where(P > 0, np.log(P), 0.0)
e = np.clip(-(1.0/ln_n) * (P*lnP).sum(0), 0.0, 1.0)
w = (1.0 - e) / (1.0 - e).sum()
wdf = pd.DataFrame({"criterion": names, "entropy": e, "weight": w})
wdf.to_csv(PROC / "EWM_weights_poverty.csv", index=False)

# ── TOPSIS ─────────────────────────────────────────────────────────────────────
Xw = X * w
A_pos, A_neg = w.copy(), np.zeros(len(w))
D_pos = np.sqrt(((Xw - A_pos)**2).sum(1))
D_neg = np.sqrt(((Xw - A_neg)**2).sum(1))
PAI = (D_neg / (D_pos + D_neg + 1e-12)).astype("float32")

# ── K-means ────────────────────────────────────────────────────────────────────
km = MiniBatchKMeans(n_clusters=N_ZONES, random_state=42, n_init=10, batch_size=100_000)
lab = km.fit_predict(PAI.reshape(-1, 1))
zmean = [PAI[lab == z].mean() for z in range(N_ZONES)]
remap = {o: r+1 for r, o in enumerate(np.argsort(zmean)[::-1])}
zranked = np.array([remap[z] for z in lab], dtype=np.uint8)

# ── write rasters ──────────────────────────────────────────────────────────────
prof = {"driver": "GTiff", "dtype": "float32", "width": ref_width, "height": ref_height,
        "count": 1, "crs": ref_crs, "transform": ref_transform, "nodata": NODATA_OUT,
        "compress": "lzw", "tiled": True, "blockxsize": 512, "blockysize": 512}
pai_grid = np.full((ref_height, ref_width), NODATA_OUT, "float32"); pai_grid[land] = PAI
with rasterio.open(PROC / "PAI_poverty_90m.tif", "w", **prof) as dst:
    dst.write(pai_grid, 1)
zone_grid = np.zeros((ref_height, ref_width), np.uint8); zone_grid[land] = zranked
with rasterio.open(PROC / "DER_zones_poverty_90m.tif", "w",
                   **{**prof, "dtype": "uint8", "nodata": 0}) as dst:
    dst.write(zone_grid, 1)

# ── compare to NTL run ─────────────────────────────────────────────────────────
print("\n=== EWM weights: NTL (published) vs Poverty (rerun) ===")
try:
    old = pd.read_csv(PROC / "EWM_weights.csv").set_index("criterion")["weight"]
except Exception:
    old = None
for nm, wi in zip(names, w):
    ow = f"{old[nm]:.3f}" if old is not None and nm in old.index else "  ?  "
    print(f"  {nm:12s}  NTL={ow}   Poverty={wi:.3f}")

print(f"\nPAI (poverty): [{PAI.min():.4f}, {PAI.max():.4f}] mean {PAI.mean():.4f}")
for z in range(1, N_ZONES+1):
    m = zranked == z
    print(f"  Zone {z}: {m.sum():,} px | PAI {PAI[m].mean():.4f}")
print(f"\nSaved: PAI_poverty_90m.tif, DER_zones_poverty_90m.tif, EWM_weights_poverty.csv")
