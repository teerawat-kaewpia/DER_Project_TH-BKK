# -*- coding: utf-8 -*-
"""
DIAGNOSTIC: does the province "equity is orthogonal, high-weight" finding
survive when the equity criterion is a VALID poverty measure (NESDC poverty
incidence) instead of the inverted-NTL/capita proxy?

Province-mean EWM-TOPSIS (77 provinces x 5 criteria), swapping C2:
  OLD C2 = inverted NTL/capita       (C2_energy_poverty_90m.tif)
  NEW C2 = poverty incidence %       (C2_poverty_province.csv, benefit)

Reports, for each C2 variant: EWM weight, Spearman rho vs PAI, and the
cross-correlation between the two C2 signals (do they even agree?).
Published pixel-level result to beat: NTL C2 weight 0.223, rho vs PAI 0.322.
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import fiona
import rasterio
from rasterstats import zonal_stats
from scipy import stats
from pathlib import Path
import os

BASE = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))  # raw data (Tier-2), override via env
PROC = BASE / "DER" / "Data" / "14_Processed_90m"
GADM = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
POV  = PROC / "C2_poverty_province.csv"

RASTERS = {
    "C1_Resource": PROC / "C1_PVOUT_90m.tif",
    "C3_Demand":   PROC / "C3_popdens_90m.tif",
    "C4_Infra":    PROC / "C5_grid_dist_90m.tif",
    "C5_Physical": PROC / "C6_land_suitability_90m.tif",
    "C2_NTL":      PROC / "C2_energy_poverty_90m.tif",   # old proxy, for comparison
}

adm1 = next(l for l in fiona.listlayers(str(GADM)) if l.endswith("_1"))
prov = gpd.read_file(str(GADM), layer=adm1)[["NAME_1", "geometry"]].to_crs("EPSG:4326")

# province means of each raster
for name, rp in RASTERS.items():
    with rasterio.open(rp) as src:
        nod = src.nodata
    zs = zonal_stats(prov, str(rp), stats=["mean"], nodata=nod)
    prov[name] = [s["mean"] for s in zs]

# poverty (valid equity)
pov = pd.read_csv(POV)[["NAME_1", "poverty_pct"]]
prov = prov.merge(pov, on="NAME_1", how="left")

def norm01(v):
    v = np.asarray(v, float)
    lo, hi = np.nanpercentile(v, 2), np.nanpercentile(v, 98)
    if hi <= lo:
        lo, hi = np.nanmin(v), np.nanmax(v)
    return np.clip((v - lo) / (hi - lo + 1e-12), 0, 1)

def ewm_topsis(Xn):
    n = Xn.shape[0]
    Xp = Xn - Xn.min(0) + 1e-6
    P = Xp / Xp.sum(0, keepdims=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        lnP = np.where(P > 0, np.log(P), 0.0)
    e = np.clip(-(1/np.log(n)) * (P*lnP).sum(0), 0, 1)
    w = (1-e) / (1-e).sum()
    Xw = Xn * w
    PAI = np.sqrt((Xw**2).sum(1)) / (np.sqrt(((Xw-w)**2).sum(1)) + np.sqrt((Xw**2).sum(1)) + 1e-12)
    return w, PAI

# common efficiency criteria (benefit, direct)
eff = ["C1_Resource", "C3_Demand", "C4_Infra", "C5_Physical"]
Xeff = np.column_stack([norm01(prov[c]) for c in eff])

results = {}
for tag, c2vals in [("NTL (old proxy)", norm01(prov["C2_NTL"])),
                    ("Poverty % (valid)", norm01(prov["poverty_pct"]))]:
    # criterion order: C1, C2, C3, C4, C5  (insert equity as 2nd)
    Xn = np.column_stack([Xeff[:, 0], c2vals, Xeff[:, 1], Xeff[:, 2], Xeff[:, 3]])
    w, PAI = ewm_topsis(Xn)
    rho, p = stats.spearmanr(c2vals, PAI)
    results[tag] = (w[1], rho, p, PAI)
    print(f"\n=== C2 = {tag} ===")
    names = ["C1_Resource", "C2_Equity", "C3_Demand", "C4_Infra", "C5_Physical"]
    for nm, wi in zip(names, w):
        print(f"  {nm:12s} w={wi:.3f}")
    print(f"  --> C2 Equity: weight={w[1]:.3f}  Spearman(C2 vs PAI)={rho:+.3f} (p={p:.3f})")

# do the two equity signals agree?
r_agree, p_agree = stats.spearmanr(norm01(prov["C2_NTL"]), norm01(prov["poverty_pct"]))
print(f"\n=== Cross-check: NTL-equity vs poverty-equity ===")
print(f"  Spearman = {r_agree:+.3f} (p={p_agree:.3f})")
print("  (low/negative => NTL proxy was NOT capturing genuine poverty)")

# PAI ranking agreement between the two equity choices
rho_pai, _ = stats.spearmanr(results["NTL (old proxy)"][3], results["Poverty % (valid)"][3])
print(f"\nPAI ranking agreement (NTL-C2 vs poverty-C2): Spearman = {rho_pai:.3f}")

# top-5 poorest provinces by the valid measure
print("\nTop 8 poorest provinces (NESDC poverty incidence %):")
print(prov.nlargest(8, "poverty_pct")[["NAME_1", "poverty_pct"]].to_string(index=False))
