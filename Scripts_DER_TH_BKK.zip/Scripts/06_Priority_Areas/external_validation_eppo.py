"""
External Validation — EPPO Province Electricity Consumption vs PAI
===================================================================
Concurrent validity check: provinces with low electricity per capita
(= high energy poverty) should rank high on PAI.

Data source: EPPO ข้อมูลการใช้ไฟฟ้ารายจังหวัด (kWh, BE 2565 = CE 2022)
Independent of model: actual billing data vs NTL satellite proxy in C2

Method:
  1. Sum 12 monthly kWh → annual provincial consumption (2022)
  2. Compute kWh per capita (WorldPop 2020 zonal sum)
  3. Normalise inverted kWh_pc → EPPO_poverty_index (high = energy poor)
  4. Spearman ρ with PAI (province mean)
  5. Zone-recall: what % of energy-poor provinces land in PAI Zone 1?
"""

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterstats import zonal_stats
from scipy.stats import spearmanr
from pathlib import Path
import os
import fiona
import warnings
warnings.filterwarnings("ignore")

BASE  = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))
PROC  = BASE / "DER" / "Data" / "14_Processed_90m"
GADM  = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
EPPO  = BASE / "Energy map" / "ข้อมูลการใช้ไฟฟารายจังหวัด2018_2025.xlsx"
POP   = BASE / "DER" / "Data" / "05_Population" / "worldpop_THA_2020_100m.tif"
NODATA = -9999.0

# Thai province name → GADM NAME_1 mapping (all 77)
THAI_TO_ENG = {
    "กรุงเทพมหานคร": "Bangkok Metropolis",
    "กระบี่": "Krabi",
    "กาญจนบุรี": "Kanchanaburi",
    "กาฬสินธุ์": "Kalasin",
    "กำแพงเพชร": "Kamphaeng Phet",
    "ขอนแก่น": "Khon Kaen",
    "จันทบุรี": "Chanthaburi",
    "ฉะเชิงเทรา": "Chachoengsao",
    "ชลบุรี": "Chon Buri",
    "ชัยนาท": "Chai Nat",
    "ชัยภูมิ": "Chaiyaphum",
    "ชุมพร": "Chumphon",
    "เชียงราย": "Chiang Rai",
    "เชียงใหม่": "Chiang Mai",
    "ตรัง": "Trang",
    "ตราด": "Trat",
    "ตาก": "Tak",
    "นครนายก": "Nakhon Nayok",
    "นครปฐม": "Nakhon Pathom",
    "นครพนม": "Nakhon Phanom",
    "นครราชสีมา": "Nakhon Ratchasima",
    "นครศรีธรรมราช": "Nakhon Si Thammarat",
    "นครสวรรค์": "Nakhon Sawan",
    "นนทบุรี": "Nonthaburi",
    "นราธิวาส": "Narathiwat",
    "น่าน": "Nan",
    "บึงกาฬ": "Bueng Kan",
    "บุรีรัมย์": "Buri Ram",
    "ปทุมธานี": "Pathum Thani",
    "ประจวบคีรีขันธ์": "Prachuap Khiri Khan",
    "ปราจีนบุรี": "Prachin Buri",
    "ปัตตานี": "Pattani",
    "พระนครศรีอยุธยา": "Phra Nakhon Si Ayutthaya",
    "พะเยา": "Phayao",
    "พังงา": "Phangnga",
    "พัทลุง": "Phatthalung",
    "พิจิตร": "Phichit",
    "พิษณุโลก": "Phitsanulok",
    "เพชรบุรี": "Phetchaburi",
    "เพชรบูรณ์": "Phetchabun",
    "แพร่": "Phrae",
    "ภูเก็ต": "Phuket",
    "มหาสารคาม": "Maha Sarakham",
    "มุกดาหาร": "Mukdahan",
    "แม่ฮ่องสอน": "Mae Hong Son",
    "ยโสธร": "Yasothon",
    "ยะลา": "Yala",
    "ร้อยเอ็ด": "Roi Et",
    "ระนอง": "Ranong",
    "ระยอง": "Rayong",
    "ราชบุรี": "Ratchaburi",
    "ลพบุรี": "Lop Buri",
    "ลำปาง": "Lampang",
    "ลำพูน": "Lamphun",
    "เลย": "Loei",
    "ศรีสะเกษ": "Si Sa Ket",
    "สกลนคร": "Sakon Nakhon",
    "สงขลา": "Songkhla",
    "สตูล": "Satun",
    "สมุทรปราการ": "Samut Prakan",
    "สมุทรสงคราม": "Samut Songkhram",
    "สมุทรสาคร": "Samut Sakhon",
    "สระแก้ว": "Sa Kaeo",
    "สระบุรี": "Saraburi",
    "สิงห์บุรี": "Sing Buri",
    "สุโขทัย": "Sukhothai",
    "สุพรรณบุรี": "Suphan Buri",
    "สุราษฎร์ธานี": "Surat Thani",
    "สุรินทร์": "Surin",
    "หนองคาย": "Nong Khai",
    "หนองบัวลำภู": "Nong Bua Lam Phu",
    "อ่างทอง": "Ang Thong",
    "อำนาจเจริญ": "Amnat Charoen",
    "อุดรธานี": "Udon Thani",
    "อุตรดิตถ์": "Uttaradit",
    "อุทัยธานี": "Uthai Thani",
    "อุบลราชธานี": "Ubon Ratchathani",
    "บึงกาฬ": "Bueng Kan",
}

# ── STEP 1: Parse EPPO sheet BE 2565 (CE 2022) ────────────────────────────────
print("=" * 60)
print("STEP 1 — EPPO Electricity Data (BE 2565 = CE 2022)")
print("=" * 60)

raw = pd.read_excel(EPPO, sheet_name="65", header=None)

# Row 1 contains column headers; rows ≥2 contain data
# Layout: col0=เขต, col1=จังหวัด, col2:14=12 monthly kWh, col14:=MoM/pct
headers = raw.iloc[1].tolist()
data    = raw.iloc[2:].copy().reset_index(drop=True)
data.columns = range(len(headers))   # use integer indices — Thai headers have NBSP

prov_col   = 1    # จังหวัด
month_cols = list(range(2, 14))     # 12 monthly kWh columns

print(f"  Province col index : {prov_col}")
print(f"  Month col indices  : {month_cols}")

# Filter: keep rows where province col is a non-null string (skip region subtotals)
data = data[data[prov_col].notna()].copy()
data = data[data[prov_col].astype(str).str.strip().str.replace('\xa0','') != ""].copy()

# Exclude region header rows (province field = region name with no numeric data)
data = data[data[2].notna()].copy()

# Convert monthly kWh columns to numeric (strip commas, NBSP)
for c in month_cols:
    data[c] = pd.to_numeric(
        data[c].astype(str).str.replace(",", "").str.replace("\xa0", "").str.strip(),
        errors="coerce"
    )

# Sum 12 months → annual kWh
data["annual_kwh"] = data[month_cols].sum(axis=1)
data["province_th"] = data[prov_col].astype(str).str.replace("\xa0","").str.strip()

# Map Thai → English
data["NAME_1"] = data["province_th"].map(THAI_TO_ENG)
unmapped = data[data["NAME_1"].isna()]["province_th"].tolist()
if unmapped:
    print(f"\n  ⚠ Unmapped provinces ({len(unmapped)}): {unmapped}")

eppo = data[["NAME_1", "province_th", "annual_kwh"]].dropna(subset=["NAME_1"]).copy()
print(f"\n  Mapped provinces: {len(eppo)} / 77")
print(f"  Annual kWh range: {eppo['annual_kwh'].min():,.0f} – {eppo['annual_kwh'].max():,.0f}")

# ── STEP 2: Province population (WorldPop zonal sum) ─────────────────────────
print("\n" + "=" * 60)
print("STEP 2 — Province Population (WorldPop zonal sum)")
print("=" * 60)

layers = fiona.listlayers(str(GADM))
adm1   = next((l for l in layers if l.endswith("_1")), layers[1])
prov   = gpd.read_file(str(GADM), layer=adm1)[["GID_1","NAME_1","geometry"]].copy()
if prov.crs.to_epsg() != 4326:
    prov = prov.to_crs("EPSG:4326")

with rasterio.open(POP) as src:
    pop_arr = src.read(1).astype("float32")
    pop_nd  = np.float32(src.nodata if src.nodata else -99999)
    pop_tfm = src.transform
    pop_arr = np.where((pop_arr == pop_nd) | (pop_arr < 0), 0.0, pop_arr)

pop_stats = zonal_stats(prov, pop_arr, affine=pop_tfm, stats=["sum"], nodata=0.0)
prov["pop_sum"] = [s["sum"] if s["sum"] else 0.0 for s in pop_stats]
print(f"  National population: {prov['pop_sum'].sum():,.0f}")
print(f"  Province pop range : {prov['pop_sum'].min():,.0f} – {prov['pop_sum'].max():,.0f}")

# ── STEP 3: Merge + compute per capita ────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 3 — Electricity Per Capita")
print("=" * 60)

pai_df = pd.read_csv(PROC / "province_PAI_summary.csv")
merged = pai_df.merge(eppo[["NAME_1","annual_kwh"]], on="NAME_1", how="left")
merged = merged.merge(prov[["NAME_1","pop_sum"]], on="NAME_1", how="left")

n_ok = merged["annual_kwh"].notna().sum()
print(f"  Matched: {n_ok} / 77 provinces")

merged["kwh_per_capita"] = merged["annual_kwh"] / merged["pop_sum"].replace(0, np.nan)

# Normalise kwh_per_capita to [0,1] then invert → EPPO poverty index
kpc_min = merged["kwh_per_capita"].min()
kpc_max = merged["kwh_per_capita"].max()
merged["kwh_pc_norm"]     = (merged["kwh_per_capita"] - kpc_min) / (kpc_max - kpc_min)
merged["eppo_pov_index"]  = 1.0 - merged["kwh_pc_norm"]   # invert: low kWh = high poverty

print(f"\n  kWh per capita range: {kpc_min:,.0f} – {kpc_max:,.0f}")
print(f"\n  Top 10 energy-poor provinces (low kWh per capita):")
top10 = merged.nlargest(10, "eppo_pov_index")[["NAME_1","kwh_per_capita","eppo_pov_index","PAI","rank"]]
print(top10.to_string(index=False))

# ── STEP 4: Spearman ρ — PAI vs EPPO poverty index ────────────────────────────
print("\n" + "=" * 60)
print("STEP 4 — Spearman Correlation (PAI vs EPPO Poverty Index)")
print("=" * 60)

valid = merged.dropna(subset=["PAI","eppo_pov_index"])
rho_full, p_full = spearmanr(valid["PAI"], valid["eppo_pov_index"])
print(f"\n  ρ (PAI vs EPPO poverty)     = {rho_full:.4f}  p={p_full:.4e}  n={len(valid)}")

# Also: PAI vs raw kWh per capita (should be negative)
rho_kwh, p_kwh = spearmanr(valid["PAI"], valid["kwh_per_capita"])
print(f"  ρ (PAI vs kWh per capita)   = {rho_kwh:.4f}  p={p_kwh:.4e}  (expected negative)")

# ── STEP 5: Zone-recall analysis ──────────────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 5 — Zone-Recall Analysis")
print("=" * 60)

# Define "energy poor" as bottom-tercile kWh per capita (lowest 26 provinces)
tercile = np.percentile(valid["kwh_per_capita"].dropna(), 33.3)
valid["is_energy_poor"] = valid["kwh_per_capita"] <= tercile
n_poor = valid["is_energy_poor"].sum()
print(f"\n  Energy-poor threshold (bottom tercile): ≤{tercile:,.0f} kWh/capita")
print(f"  Energy-poor provinces: {n_poor}")

# Check how many land in PAI Zone 1 or 2
for zone_thresh in [1, 2]:
    in_zone = valid[valid["is_energy_poor"] & (valid["dominant_zone"] <= zone_thresh)]
    recall = len(in_zone) / n_poor * 100
    print(f"  Energy-poor in PAI Zone ≤{zone_thresh}: {len(in_zone)}/{n_poor} ({recall:.1f}% recall)")

# Precision: of Zone 1 provinces, how many are energy-poor?
zone1 = valid[valid["dominant_zone"] == 1]
prec = (zone1["is_energy_poor"].sum() / len(zone1) * 100) if len(zone1) > 0 else 0
print(f"  PAI Zone 1 that are energy-poor: {zone1['is_energy_poor'].sum()}/{len(zone1)} ({prec:.1f}% precision)")

# ── STEP 6: Full table sorted by PAI rank ─────────────────────────────────────
print("\n" + "=" * 60)
print("STEP 6 — FULL 77-PROVINCE VALIDATION TABLE")
print("=" * 60)

out = merged[["rank","NAME_1","PAI","dominant_zone","annual_kwh","kwh_per_capita","eppo_pov_index"]].copy()
out = out.sort_values("rank").reset_index(drop=True)
out["kwh_per_capita"] = out["kwh_per_capita"].map(lambda x: f"{x:,.0f}" if pd.notna(x) else "—")
out["annual_kwh"]     = out["annual_kwh"].map(lambda x: f"{x/1e6:.1f}M" if pd.notna(x) else "—")
out["eppo_pov_index"] = out["eppo_pov_index"].round(3)
print(out.to_string(index=False))

# ── Save ──────────────────────────────────────────────────────────────────────
save_cols = ["rank","NAME_1","PAI","dominant_zone","annual_kwh","kwh_per_capita","eppo_pov_index"]
save_df = merged[save_cols].copy().sort_values("rank")
save_df.to_csv(PROC / "external_validation_eppo.csv", index=False, encoding="utf-8-sig")
print(f"\nSaved: {PROC / 'external_validation_eppo.csv'}")
