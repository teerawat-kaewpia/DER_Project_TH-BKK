# -*- coding: utf-8 -*-
"""
Collinearity robustness test for C3 Demand vs C4 Infrastructure.
=================================================================
C3 (population density) and C4 (grid accessibility) are strongly correlated
(r = 0.912; VIF 6.59 / 5.97), which invites the criticism that the index
double-counts the same "urban + grid advantage".

Test: recompute the full pixel-level EWM-TOPSIS pipeline under four criterion
sets and compare the resulting PROVINCE rankings (n = 77) against the baseline:
  S0 baseline   C1 C2 C3 C4 C5   (published model)
  S1 drop C3    C1 C2    C4 C5
  S2 drop C4    C1 C2 C3    C5
  S3 merge      C1 C2 (C3+C4)/2 C5   -- single "urban-grid access" criterion

If rankings stay highly concordant, the collinearity is not driving the result.
Output: DER/Data/14_Processed_90m/sensitivity_c3c4_collinearity.csv
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
import fiona
from rasterstats import zonal_stats
from scipy import stats
from pathlib import Path
import os
import warnings
warnings.filterwarnings("ignore")

BASE = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))  # raw data (Tier-2), override via env
PROC = BASE / "DER" / "Data" / "14_Processed_90m"
GADM = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
REF  = BASE / "Energy map" / "Thailand_DEM_90m.tif"

LAYERS = {
    "C1": PROC / "C1_PVOUT_90m.tif",
    "C2": PROC / "C2_poverty_90m.tif",
    "C3": PROC / "C3_popdens_90m.tif",
    "C4": PROC / "C5_grid_dist_90m.tif",
    "C5": PROC / "C6_land_suitability_90m.tif",
}

with rasterio.open(REF) as ref:
    H, W, TR, CRS = ref.height, ref.width, ref.transform, ref.crs

print("Loading criterion rasters...")
arr, nod = {}, {}
for k, p in LAYERS.items():
    with rasterio.open(p) as s:
        arr[k] = s.read(1).astype("float32")
        nod[k] = np.float32(s.nodata if s.nodata is not None else -9999.0)

land = np.ones((H, W), bool)
for k in LAYERS:
    land &= (arr[k] != nod[k])
print(f"  land pixels: {land.sum():,}")
X = {k: arr[k][land] for k in LAYERS}


def ewm_topsis(cols):
    """cols: dict name->1D array. Returns pixel PAI."""
    M = np.column_stack([cols[c] for c in cols]).astype("float64")
    n = M.shape[0]
    Mp = M - M.min(0) + 1e-6
    P = Mp / Mp.sum(0, keepdims=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        lnP = np.where(P > 0, np.log(P), 0.0)
    e = np.clip(-(1.0 / np.log(n)) * (P * lnP).sum(0), 0.0, 1.0)
    w = (1 - e) / (1 - e).sum()
    Mw = M * w
    dpos = np.sqrt(((Mw - w) ** 2).sum(1))
    dneg = np.sqrt((Mw ** 2).sum(1))
    return (dneg / (dpos + dneg + 1e-12)).astype("float32"), w


SCEN = {
    "S0_baseline": {k: X[k] for k in ["C1", "C2", "C3", "C4", "C5"]},
    "S1_drop_C3":  {k: X[k] for k in ["C1", "C2", "C4", "C5"]},
    "S2_drop_C4":  {k: X[k] for k in ["C1", "C2", "C3", "C5"]},
    "S3_merge":    {"C1": X["C1"], "C2": X["C2"],
                    "C34": (X["C3"] + X["C4"]) / 2.0, "C5": X["C5"]},
}

# province geometries once
adm1 = next(l for l in fiona.listlayers(str(GADM)) if l.endswith("_1"))
prov = gpd.read_file(str(GADM), layer=adm1)[["NAME_1", "geometry"]].to_crs(CRS)

prov_pai = {}
for name, cols in SCEN.items():
    pai, w = ewm_topsis(cols)
    grid = np.full((H, W), np.nan, "float32")
    grid[land] = pai
    zs = zonal_stats(prov, grid, affine=TR, stats=["mean"], nodata=np.nan)
    prov_pai[name] = np.array([z["mean"] for z in zs], float)
    print(f"  {name:12s} weights=" + " ".join(f"{c}:{wi:.3f}" for c, wi in zip(cols, w)))

df = pd.DataFrame(prov_pai)
df.insert(0, "NAME_1", prov["NAME_1"].values)
for c in prov_pai:
    df[c + "_rank"] = df[c].rank(ascending=False).astype(int)

print("\n=== Province-ranking concordance vs baseline (n = 77) ===")
rows = []
for name in ["S1_drop_C3", "S2_drop_C4", "S3_merge"]:
    rho, p = stats.spearmanr(df["S0_baseline"], df[name])
    tau, _ = stats.kendalltau(df["S0_baseline_rank"], df[name + "_rank"])
    shift = (df["S0_baseline_rank"] - df[name + "_rank"]).abs()
    rows.append({"scenario": name, "spearman_rho": round(rho, 3),
                 "kendall_tau": round(tau, 3),
                 "max_rank_shift": int(shift.max()),
                 "n_shift_gt5": int((shift > 5).sum())})
    print(f"  {name:12s} rho={rho:.3f}  tau={tau:.3f}  max shift={int(shift.max())}  "
          f"(#>5 ranks: {int((shift>5).sum())})")

out = pd.DataFrame(rows)
out.to_csv(PROC / "sensitivity_c3c4_collinearity.csv", index=False, encoding="utf-8-sig")
df.to_csv(PROC / "sensitivity_c3c4_province_detail.csv", index=False, encoding="utf-8-sig")
print(f"\nSaved: sensitivity_c3c4_collinearity.csv")
