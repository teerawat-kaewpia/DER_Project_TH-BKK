# -*- coding: utf-8 -*-
"""
Province-level summary + NTL-vs-poverty comparison for the poverty PAI rerun.
Answers the key questions:
  - Is the equity criterion still ORTHOGONAL to the composite with real poverty?
  - How much does the province ranking change vs the NTL version?
  - Does spatial autocorrelation (Moran's I) hold?
Output: province_PAI_summary_poverty.csv
"""
import numpy as np
import pandas as pd
import geopandas as gpd
import fiona
import rasterio
from rasterstats import zonal_stats
from scipy import stats
from pathlib import Path
import os

BASE = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))  # raw data (Tier-2), override via env
PROC = BASE / "DER" / "Data" / "14_Processed_90m"
GADM = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"

adm1 = next(l for l in fiona.listlayers(str(GADM)) if l.endswith("_1"))
prov = gpd.read_file(str(GADM), layer=adm1)[["NAME_1", "geometry"]].to_crs("EPSG:4326")

def zmean(rp, col):
    with rasterio.open(rp) as s:
        nod = s.nodata
    prov[col] = [z["mean"] for z in zonal_stats(prov, str(rp), stats=["mean"], nodata=nod)]

zmean(PROC / "PAI_poverty_90m.tif", "PAI_pov")
for c, f in [("C1", "C1_PVOUT_90m.tif"), ("C2", "C2_poverty_90m.tif"),
             ("C3", "C3_popdens_90m.tif"), ("C4", "C5_grid_dist_90m.tif"),
             ("C5", "C6_land_suitability_90m.tif")]:
    zmean(PROC / f, c)

prov["rank_pov"] = prov["PAI_pov"].rank(ascending=False).astype(int)

# merge NTL version
ntl = pd.read_csv(PROC / "province_PAI_summary.csv")[["NAME_1", "PAI", "rank", "C2"]]
ntl.columns = ["NAME_1", "PAI_ntl", "rank_ntl", "C2_ntl"]
m = prov.drop(columns="geometry").merge(ntl, on="NAME_1", how="left")

# ── orthogonality: C2(poverty) vs poverty-PAI ─────────────────────────────────
r_p, p_p = stats.pearsonr(m["C2"], m["PAI_pov"])
r_s, p_s = stats.spearmanr(m["C2"], m["PAI_pov"])
print("=== Equity orthogonality (province level) ===")
print(f"  C2 poverty  vs PAI:  Pearson r={r_p:+.3f} (p={p_p:.3f})  Spearman rho={r_s:+.3f} (p={p_s:.3f})")
r_s_ntl, p_s_ntl = stats.spearmanr(m["C2_ntl"], m["PAI_ntl"])
print(f"  C2 NTL(old) vs PAI:  Spearman rho={r_s_ntl:+.3f} (p={p_s_ntl:.3f})   [published pixel value 0.322]")

# other criteria vs poverty-PAI
print("\n=== Each criterion vs poverty-PAI (Spearman) ===")
for c, lab in [("C1","Resource"),("C2","Equity(pov)"),("C3","Demand"),("C4","Infra"),("C5","Physical")]:
    rr, pp = stats.spearmanr(m[c], m["PAI_pov"])
    print(f"  {lab:12s} rho={rr:+.3f} (p={pp:.3f})")

# ── ranking agreement NTL vs poverty ──────────────────────────────────────────
r_rank, _ = stats.spearmanr(m["PAI_ntl"], m["PAI_pov"])
maxshift = int((m["rank_ntl"] - m["rank_pov"]).abs().max())
print(f"\n=== Province ranking: NTL vs poverty ===")
print(f"  Spearman rho={r_rank:.3f} | max rank shift={maxshift}")

# ── Moran's I on poverty-PAI ──────────────────────────────────────────────────
try:
    from libpysal.weights import Queen
    from esda.moran import Moran
    gg = prov.merge(m[["NAME_1","PAI_pov"]], on="NAME_1")
    W = Queen.from_dataframe(gg, use_index=False); W.transform = "r"
    mi = Moran(gg["PAI_pov"].values, W, permutations=999)
    print(f"\nMoran's I (poverty-PAI) = {mi.I:.4f} (p={mi.p_sim:.4f})   [NTL published 0.687]")
except Exception as ex:
    print(f"Moran skipped: {ex}")

# ── top/bottom + biggest movers ───────────────────────────────────────────────
print("\n=== Top 10 provinces (poverty-PAI) with NTL rank ===")
print(m.nsmallest(10, "rank_pov")[["NAME_1","PAI_pov","rank_pov","rank_ntl","C2"]].to_string(index=False))
m["shift"] = m["rank_ntl"] - m["rank_pov"]
print("\n=== Biggest RISERS under real poverty (rank improved most) ===")
print(m.nlargest(6, "shift")[["NAME_1","rank_ntl","rank_pov","shift","C2"]].to_string(index=False))
print("=== Biggest FALLERS ===")
print(m.nsmallest(6, "shift")[["NAME_1","rank_ntl","rank_pov","shift","C2"]].to_string(index=False))

m.to_csv(PROC / "province_PAI_summary_poverty.csv", index=False, encoding="utf-8-sig")
print(f"\nSaved: province_PAI_summary_poverty.csv")
