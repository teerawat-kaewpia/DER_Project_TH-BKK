"""
Province-level PAI statistics and DER zone breakdown
=====================================================
For each province: mean PAI, zone distribution (%), dominant zone,
all 6 criterion means. Output: CSV for paper results section.
"""

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
from rasterstats import zonal_stats
from pathlib import Path
import os
import fiona
import warnings
warnings.filterwarnings("ignore")

BASE     = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))
PROC     = BASE / "DER" / "Data" / "14_Processed_90m"
GADM     = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
OUT_CSV  = PROC / "province_PAI_summary.csv"
N_ZONES  = 5

LAYERS = {
    "PAI":   PROC / "PAI_90m.tif",
    "C1":    PROC / "C1_PVOUT_90m.tif",
    "C2":    PROC / "C2_poverty_90m.tif",
    "C3":    PROC / "C3_popdens_90m.tif",
    "C4":    PROC / "C4_ERP_proxy_NTL_90m.tif",
    "C5":    PROC / "C5_grid_access_90m.tif",
    "C6":    PROC / "C6_land_suitability_90m.tif",
}
ZONES_TIF = PROC / "DER_zones_90m.tif"

# ── Load provinces ─────────────────────────────────────────────────────────────
print("Loading GADM provinces...")
layers = fiona.listlayers(str(GADM))
adm1   = next((l for l in layers if l.endswith("_1")), layers[1])
prov   = gpd.read_file(str(GADM), layer=adm1)
prov   = prov[["GID_1", "NAME_1", "geometry"]].copy()
with rasterio.open(LAYERS["PAI"]) as src:
    if prov.crs != src.crs:
        prov = prov.to_crs(src.crs)
print(f"  {len(prov)} provinces")

# ── Zonal mean for each continuous layer ──────────────────────────────────────
print("Computing zonal means...")
for col, tif in LAYERS.items():
    with rasterio.open(tif) as src:
        nd = src.nodata if src.nodata is not None else -9999.0
        arr = src.read(1).astype("float32")
        tfm = src.transform
    stats = zonal_stats(prov, arr, affine=tfm, stats=["mean"], nodata=nd)
    prov[col] = [s["mean"] if s["mean"] is not None else np.nan for s in stats]
    print(f"  {col}: done")

# ── Zone distribution per province (categorical pixel count) ──────────────────
print("Computing zone distribution...")
with rasterio.open(ZONES_TIF) as src:
    zone_arr = src.read(1)   # uint8: 0=nodata, 1–5=zones
    zone_tfm = src.transform

# zonal_stats categorical=True: returns {zone_val: pixel_count}
cat_stats = zonal_stats(prov, zone_arr, affine=zone_tfm,
                        categorical=True, nodata=0)

zone_cols = [f"zone{z}_pct" for z in range(1, N_ZONES + 1)]
for i, row_counts in enumerate(cat_stats):
    total = sum(row_counts.get(z, 0) for z in range(1, N_ZONES + 1))
    total = total if total > 0 else 1
    for z in range(1, N_ZONES + 1):
        prov.loc[prov.index[i], f"zone{z}_pct"] = round(
            row_counts.get(z, 0) / total * 100, 1
        )

# Dominant zone = zone with highest %
prov["dominant_zone"] = prov[zone_cols].idxmax(axis=1).str.extract(r"(\d+)").astype(int)

# ── Sort by PAI descending ─────────────────────────────────────────────────────
prov = prov.sort_values("PAI", ascending=False).reset_index(drop=True)
prov["rank"] = prov.index + 1

# ── Round for output ──────────────────────────────────────────────────────────
float_cols = ["PAI", "C1", "C2", "C3", "C4", "C5", "C6"]
prov[float_cols] = prov[float_cols].round(4)
prov[zone_cols]  = prov[zone_cols].round(1)

# ── Save ──────────────────────────────────────────────────────────────────────
out = prov.drop(columns="geometry")
out.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")
print(f"\nSaved: {OUT_CSV}")

# ── Print top / bottom 10 ─────────────────────────────────────────────────────
print("\n=== Top 10 highest-priority provinces ===")
top10 = out[["rank", "NAME_1", "PAI", "dominant_zone", "C1", "C2", "C3", "C4", "C5", "C6"]].head(10)
print(top10.to_string(index=False))

print("\n=== Bottom 10 lowest-priority provinces ===")
bot10 = out[["rank", "NAME_1", "PAI", "dominant_zone", "C1", "C2", "C3", "C4", "C5", "C6"]].tail(10)
print(bot10.to_string(index=False))

print("\n=== National zone distribution (mean % across provinces) ===")
for z in range(1, N_ZONES + 1):
    avg_pct = prov[f"zone{z}_pct"].mean()
    print(f"  Zone {z}: {avg_pct:.1f}%")
