"""
Uncertainty Analysis for DER Priority Area Index (PAI) — S2 Final Model
========================================================================
Three complementary analyses:

  A. Bootstrap EWM weights (N=1000, province level)
     Resample 77-province criterion matrix with replacement ->
     recompute EWM -> weight 95% CI per criterion

  B. Monte Carlo — criterion value noise (N=1000, province-level)
     Gaussian noise (sigma=5%) on each criterion province mean ->
     recompute EWM + TOPSIS -> PAI 95% CI per province, rank stability

  C. Dirichlet weight perturbation (N=1000)
     Perturb EWM weights via Dirichlet(alpha=EWM_w * kappa, kappa=50) ->
     TOPSIS -> zone assignment probability per province

All analyses operate at province level (77 data points) for consistency
with the main EWM-TOPSIS pipeline which uses province means.
"""

import numpy as np
import pandas as pd
import rasterio
import fiona
import geopandas as gpd
from rasterstats import zonal_stats
from scipy.stats import spearmanr
from pathlib import Path
import os
import warnings
warnings.filterwarnings("ignore")

rng = np.random.default_rng(42)

BASE  = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))
PROC  = BASE / "DER" / "Data" / "14_Processed_90m"
GADM  = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
NODATA = -9999.0

CRIT_NAMES = ["C1_Solar", "C2_Poverty", "C3_PopDens", "C4_GridDist", "C5_LandSuit"]
CRIT_FILES = {
    "C1_Solar":    PROC / "C1_PVOUT_90m.tif",
    "C2_Poverty":  PROC / "C2_energy_poverty_90m.tif",
    "C3_PopDens":  PROC / "C3_popdens_90m.tif",
    "C4_GridDist": PROC / "C5_grid_dist_90m.tif",
    "C5_LandSuit": PROC / "C6_land_suitability_90m.tif",
}
W_EWM = np.array([0.237370, 0.222562, 0.121098, 0.181601, 0.237370])
N_CRIT = 5
N_ZONES = 5

# ── Load province boundaries ───────────────────────────────────────────────────
print("Loading provinces...")
layers = fiona.listlayers(str(GADM))
adm1   = next(l for l in layers if l.endswith("_1"))
prov   = gpd.read_file(str(GADM), layer=adm1)[["GID_1", "NAME_1", "geometry"]].copy()
if prov.crs.to_epsg() != 4326:
    prov = prov.to_crs("EPSG:4326")
print(f"  {len(prov)} provinces")

# ── Load base rasters ──────────────────────────────────────────────────────────
print("Loading criterion rasters...")
arrays, ndvals = {}, {}
for name, path in CRIT_FILES.items():
    with rasterio.open(path) as src:
        arr = src.read(1).astype("float32")
        nd  = np.float32(src.nodata if src.nodata is not None else -9999.0)
    arrays[name] = arr
    ndvals[name] = nd

land_mask = np.ones(arrays["C1_Solar"].shape, dtype=bool)
for name in CRIT_NAMES:
    land_mask &= (arrays[name] != ndvals[name])
n_pix = land_mask.sum()
print(f"  Land pixels: {n_pix:,}")

X_full = np.stack([arrays[n][land_mask] for n in CRIT_NAMES], axis=1).astype("float32")

# ── Province mean criterion matrix (77 × 5) ────────────────────────────────────
print("Computing province-level criterion means...")
with rasterio.open(CRIT_FILES["C1_Solar"]) as src:
    tfm = src.transform

prov_means = {}
for name, path in CRIT_FILES.items():
    stats = zonal_stats(prov, arrays[name], affine=tfm, stats=["mean"],
                        nodata=float(ndvals[name]))
    prov_means[name] = np.array([s["mean"] if s["mean"] is not None else 0.0
                                  for s in stats])

Xp = np.column_stack([prov_means[n] for n in CRIT_NAMES]).astype("float64")  # 77×5
print(f"  Province matrix shape: {Xp.shape}")

# ── TOPSIS (theoretical bounds, province level) ───────────────────────────────
def topsis_prov(X, w):
    """X: (n_prov, 5) in [0,1]; w: (5,); returns closeness coeff (n_prov,)."""
    Xw = X * w[np.newaxis, :]
    Ap = w.copy()
    An = np.zeros(len(w))
    Dp = np.sqrt(((Xw - Ap) ** 2).sum(axis=1))
    Dn = np.sqrt(((Xw - An) ** 2).sum(axis=1))
    return Dn / (Dp + Dn + 1e-12)

# ── EWM (province level, matches pixel-level result well) ─────────────────────
def ewm_weights(X):
    """X: (n, 5) any matrix; returns weights (5,)."""
    X_pos = X - X.min(axis=0) + 1e-9
    col_sum = X_pos.sum(axis=0)
    P = X_pos / col_sum[np.newaxis, :]
    n = X.shape[0]
    ln_n = np.log(n)
    with np.errstate(divide="ignore", invalid="ignore"):
        lnP = np.where(P > 0, np.log(P), 0.0)
    e = -(1.0 / ln_n) * (P * lnP).sum(axis=0)
    e = np.clip(e, 0.0, 1.0)
    d = 1.0 - e
    return d / d.sum()

def zone_from_pai(pai, breaks):
    """Assign zone 1-5 given PAI value and sorted zone break thresholds."""
    z = np.digitize(pai, breaks) + 1
    return np.clip(z, 1, N_ZONES)

# Pre-compute zone breaks from original PAI
pai_base = topsis_prov(Xp, W_EWM)
pai_sorted = np.sort(pai_base)
# Use original K-means zone boundaries from the full raster (hardcoded from pipeline output)
ZONE_BREAKS = [0.1958, 0.3206, 0.4409, 0.5394]  # boundaries between zones 5↔4↔3↔2↔1

base_ranks  = pd.Series(pai_base).rank(ascending=False).values
base_zone   = np.array([5 - np.searchsorted(ZONE_BREAKS, p) for p in pai_base])
base_zone   = np.clip(base_zone, 1, 5)

print(f"\nBaseline PAI: [{pai_base.min():.4f}, {pai_base.max():.4f}] mean={pai_base.mean():.4f}")

# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS A — Bootstrap EWM weights (province level, 77 data points)
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("ANALYSIS A — Bootstrap EWM Weights (N=1000, province level)")
print("=" * 60)

N_BOOT = 1000
n_prov = len(prov)
print(f"  Province matrix: {n_prov} x {N_CRIT}")

boot_weights = np.zeros((N_BOOT, N_CRIT))
for b in range(N_BOOT):
    # Resample 77 provinces with replacement
    idx = rng.choice(n_prov, size=n_prov, replace=True)
    boot_weights[b] = ewm_weights(Xp[idx])
    if (b + 1) % 200 == 0:
        print(f"  Bootstrap {b+1}/{N_BOOT} done")

boot_mean = boot_weights.mean(axis=0)
boot_ci_lo = np.percentile(boot_weights, 2.5, axis=0)
boot_ci_hi = np.percentile(boot_weights, 97.5, axis=0)
boot_sd    = boot_weights.std(axis=0)

print("\n  Bootstrap Weight Results:")
print(f"  {'Criterion':<15} {'EWM':>7} {'Boot_mean':>10} {'CI_lo':>7} {'CI_hi':>7} {'SD':>7}")
for j, name in enumerate(CRIT_NAMES):
    print(f"  {name:<15} {W_EWM[j]:>7.4f} {boot_mean[j]:>10.4f} "
          f"{boot_ci_lo[j]:>7.4f} {boot_ci_hi[j]:>7.4f} {boot_sd[j]:>7.4f}")

# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS B — Monte Carlo criterion noise (province-level, N=1000)
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("ANALYSIS B — Monte Carlo Criterion Noise (N=1000, sigma=5%)")
print("=" * 60)

N_MC = 1000
SIGMA_FRAC = 0.05    # 5% Gaussian noise (sigma) on province criterion means

mc_pai    = np.zeros((N_MC, len(prov)))
mc_ranks  = np.zeros((N_MC, len(prov)), dtype=int)
mc_zones  = np.zeros((N_MC, len(prov)), dtype=int)
mc_weights = np.zeros((N_MC, N_CRIT))

crit_ranges = Xp.max(axis=0) - Xp.min(axis=0)  # range per criterion

for m in range(N_MC):
    noise = rng.normal(0, SIGMA_FRAC * crit_ranges[np.newaxis, :], size=Xp.shape)
    Xp_n  = np.clip(Xp + noise, 0.0, 1.0)
    w_n   = ewm_weights(Xp_n)
    pai_n = topsis_prov(Xp_n, w_n)
    mc_pai[m]    = pai_n
    mc_ranks[m]  = pd.Series(pai_n).rank(ascending=False).values.astype(int)
    mc_zones[m]  = np.clip(
        5 - np.array([np.searchsorted(ZONE_BREAKS, p) for p in pai_n]), 1, 5)
    mc_weights[m] = w_n
    if (m + 1) % 200 == 0:
        print(f"  MC iteration {m+1}/{N_MC} done")

pai_mc_mean  = mc_pai.mean(axis=0)
pai_mc_sd    = mc_pai.std(axis=0)
pai_mc_ci_lo = np.percentile(mc_pai, 2.5, axis=0)
pai_mc_ci_hi = np.percentile(mc_pai, 97.5, axis=0)

rank_mc_med  = np.median(mc_ranks, axis=0).astype(int)
rank_mc_iqr  = (np.percentile(mc_ranks, 75, axis=0) -
                np.percentile(mc_ranks, 25, axis=0)).astype(int)

# Zone assignment probability matrix (77 × 5)
zone_prob = np.zeros((len(prov), N_ZONES))
for z in range(1, N_ZONES + 1):
    zone_prob[:, z - 1] = (mc_zones == z).mean(axis=0)

# Spearman ρ between base PAI and each MC iteration
rho_mc = np.array([spearmanr(pai_base, mc_pai[m]).statistic for m in range(N_MC)])
print(f"\n  Spearman rho(baseline, MC): mean={rho_mc.mean():.4f} "
      f"  min={rho_mc.min():.4f}  p5={np.percentile(rho_mc,5):.4f}")

print(f"\n  PAI uncertainty (province level):")
print(f"  mean SD        = {pai_mc_sd.mean():.4f}")
print(f"  max SD         = {pai_mc_sd.max():.4f}  "
      f"({prov['NAME_1'].iloc[pai_mc_sd.argmax()]})")
print(f"  mean CI width  = {(pai_mc_ci_hi - pai_mc_ci_lo).mean():.4f}")

# MC weight uncertainty
print(f"\n  MC Weight uncertainty (mean ± 95% CI):")
mc_w_mean  = mc_weights.mean(axis=0)
mc_w_cilo  = np.percentile(mc_weights, 2.5, axis=0)
mc_w_cihi  = np.percentile(mc_weights, 97.5, axis=0)
for j, name in enumerate(CRIT_NAMES):
    print(f"  {name:<15} {mc_w_mean[j]:.4f}  [{mc_w_cilo[j]:.4f}, {mc_w_cihi[j]:.4f}]")

# ══════════════════════════════════════════════════════════════════════════════
# ANALYSIS C — Dirichlet weight perturbation (N=1000)
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("ANALYSIS C — Dirichlet Weight Perturbation (N=1000, κ=50)")
print("=" * 60)

N_DIR = 1000
KAPPA = 50.0   # concentration parameter; higher = tighter around EWM weights

dir_alpha  = W_EWM * KAPPA
dir_pai    = np.zeros((N_DIR, len(prov)))
dir_ranks  = np.zeros((N_DIR, len(prov)), dtype=int)
dir_zones  = np.zeros((N_DIR, len(prov)), dtype=int)
dir_weights = np.zeros((N_DIR, N_CRIT))

for d in range(N_DIR):
    w_d = rng.dirichlet(dir_alpha)
    dir_weights[d] = w_d
    pai_d = topsis_prov(Xp, w_d)
    dir_pai[d]   = pai_d
    dir_ranks[d] = pd.Series(pai_d).rank(ascending=False).values.astype(int)
    dir_zones[d] = np.clip(
        5 - np.array([np.searchsorted(ZONE_BREAKS, p) for p in pai_d]), 1, 5)

dir_pai_mean  = dir_pai.mean(axis=0)
dir_pai_sd    = dir_pai.std(axis=0)
dir_pai_ci_lo = np.percentile(dir_pai, 2.5, axis=0)
dir_pai_ci_hi = np.percentile(dir_pai, 97.5, axis=0)

dir_rank_med = np.median(dir_ranks, axis=0).astype(int)
dir_rank_iqr = (np.percentile(dir_ranks, 75, axis=0) -
                np.percentile(dir_ranks, 25, axis=0)).astype(int)

dir_zone_prob = np.zeros((len(prov), N_ZONES))
for z in range(1, N_ZONES + 1):
    dir_zone_prob[:, z - 1] = (dir_zones == z).mean(axis=0)

rho_dir = np.array([spearmanr(pai_base, dir_pai[d]).statistic for d in range(N_DIR)])
print(f"  Spearman rho(baseline, Dirichlet): mean={rho_dir.mean():.4f} "
      f"  min={rho_dir.min():.4f}  p5={np.percentile(rho_dir,5):.4f}")

# Rank-stable provinces: IQR(rank) ≤ 5 in Dirichlet analysis
n_stable_dir = (dir_rank_iqr <= 5).sum()
print(f"  Provinces with rank IQR ≤ 5: {n_stable_dir}/77 ({n_stable_dir/77*100:.0f}%)")

# ══════════════════════════════════════════════════════════════════════════════
# Compile full province uncertainty table
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("FULL PROVINCE UNCERTAINTY TABLE")
print("=" * 60)

base_pai_df = pd.read_csv(PROC / "province_PAI_summary.csv")

out = pd.DataFrame({
    "NAME_1": prov["NAME_1"].values,
    "PAI_base": pai_base.round(4),
    "rank_base": base_ranks.astype(int),
    "zone_base": base_zone,
    # Monte Carlo
    "PAI_MC_mean": pai_mc_mean.round(4),
    "PAI_MC_sd":   pai_mc_sd.round(4),
    "PAI_MC_ci_lo": pai_mc_ci_lo.round(4),
    "PAI_MC_ci_hi": pai_mc_ci_hi.round(4),
    "rank_MC_median": rank_mc_med,
    "rank_MC_iqr":    rank_mc_iqr,
    # Zone probability (from MC)
    "P_zone1_MC": zone_prob[:, 0].round(3),
    "P_zone2_MC": zone_prob[:, 1].round(3),
    "P_zone3_MC": zone_prob[:, 2].round(3),
    # Dirichlet
    "PAI_Dir_mean": dir_pai_mean.round(4),
    "PAI_Dir_sd":   dir_pai_sd.round(4),
    "rank_Dir_median": dir_rank_med,
    "rank_Dir_iqr":    dir_rank_iqr,
    "P_zone1_Dir": dir_zone_prob[:, 0].round(3),
})

out = out.sort_values("rank_base").reset_index(drop=True)
print(out[["NAME_1", "PAI_base", "PAI_MC_ci_lo", "PAI_MC_ci_hi",
           "rank_base", "rank_MC_iqr", "P_zone1_MC"]].head(20).to_string(index=False))

# Bootstrap weight table
boot_tbl = pd.DataFrame({
    "Criterion":  CRIT_NAMES,
    "W_EWM":      W_EWM.round(4),
    "Boot_mean":  boot_mean.round(4),
    "Boot_SD":    boot_sd.round(4),
    "Boot_CI_lo": boot_ci_lo.round(4),
    "Boot_CI_hi": boot_ci_hi.round(4),
    "MC_CI_lo":   mc_w_cilo.round(4),
    "MC_CI_hi":   mc_w_cihi.round(4),
})
print("\nWeight uncertainty table:")
print(boot_tbl.to_string(index=False))

# ── Summary stats for paper ────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("SUMMARY STATISTICS FOR PAPER")
print("=" * 60)
ci_width_mc  = (pai_mc_ci_hi  - pai_mc_ci_lo).mean()
ci_width_dir = (dir_pai_ci_hi - dir_pai_ci_lo).mean()
rho_mc_p5    = np.percentile(rho_mc, 5)
rho_dir_p5   = np.percentile(rho_dir, 5)
n_stable_mc  = (rank_mc_iqr <= 5).sum()
n_topzone_stable = ((zone_prob[:, 0] >= 0.80) | (zone_prob[:, 1] >= 0.80)).sum()

print(f"  MC   : mean 95% CI width = {ci_width_mc:.4f}  |  Spearman rho P5 = {rho_mc_p5:.4f}")
print(f"  Dir  : mean 95% CI width = {ci_width_dir:.4f}  |  Spearman rho P5 = {rho_dir_p5:.4f}")
print(f"  MC   : provinces rank-IQR ≤ 5 = {n_stable_mc}/77")
print(f"  Dir  : provinces rank-IQR ≤ 5 = {n_stable_dir}/77")
print(f"  MC   : provinces P(assigned zone) ≥ 80% = {n_topzone_stable}/77")
print(f"  Bootstrap weight: max CI width = "
      f"{(boot_ci_hi - boot_ci_lo).max():.4f} "
      f"({CRIT_NAMES[np.argmax(boot_ci_hi - boot_ci_lo)]})")
print(f"  MC weight:        max CI width = "
      f"{(mc_w_cihi - mc_w_cilo).max():.4f} "
      f"({CRIT_NAMES[np.argmax(mc_w_cihi - mc_w_cilo)]})")

# ── Save outputs ───────────────────────────────────────────────────────────────
out.to_csv(PROC / "uncertainty_analysis.csv", index=False, encoding="utf-8-sig")
boot_tbl.to_csv(PROC / "uncertainty_weights.csv", index=False, encoding="utf-8-sig")
print(f"\nSaved: {PROC / 'uncertainty_analysis.csv'}")
print(f"Saved: {PROC / 'uncertainty_weights.csv'}")
print("\n=== COMPLETE ===")
