# -*- coding: utf-8 -*-
"""
OSM solar-plant validation on the POVERTY-based zones (vs the published NTL zones).
Key question: does the equity-corrected Zone 1 still align with existing solar
deployment, or does it (correctly) shift toward under-served poor provinces?
"""
import json, numpy as np, pandas as pd, rasterio, geopandas as fake, fiona
import geopandas as gpd
from rasterio.transform import rowcol
from shapely.geometry import shape, Point
from scipy.stats import spearmanr, chi2_contingency
from rasterstats import zonal_stats
from pathlib import Path
import os
import warnings; warnings.filterwarnings("ignore")

BASE = Path(os.environ.get("ENERGY_DATA_ROOT", r"D:\Clude Code GIS\Energy"))  # raw data (Tier-2), override via env
PROC = BASE / "DER" / "Data" / "14_Processed_90m"
GADM = BASE / "DER" / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
PLANTS = BASE / "Energy map" / "GridNetwork_OSM" / "plants.geojson"

def run(zone_tif, pai_tif, tag):
    with open(PLANTS, encoding="utf-8") as fh:
        data = json.load(fh)
    pts = []
    for ft in data["features"]:
        pr = ft.get("properties", {})
        src = (pr.get("generator:source") or pr.get("plant:source") or pr.get("power_source") or "")
        if src.lower() != "solar":
            continue
        g = ft.get("geometry")
        if not g:
            continue
        s = shape(g); p = s.centroid if s.geom_type != "Point" else s
        if p.is_empty or p.x == 0.0:
            continue
        pts.append((p.x, p.y))
    sg = gpd.GeoDataFrame(geometry=[Point(x, y) for x, y in pts], crs="EPSG:4326")
    sg = sg.cx[97.5:106.0, 5.0:21.0]

    with rasterio.open(zone_tif) as src:
        zone = src.read(1); tfm = src.transform
    zc = {z: int((zone == z).sum()) for z in range(1, 6)}
    tot = sum(zc.values()); frac = {z: zc[z] / tot for z in range(1, 6)}

    zs = []
    for _, r in sg.iterrows():
        rr, cc = rowcol(tfm, r.geometry.x, r.geometry.y)
        if 0 <= rr < zone.shape[0] and 0 <= cc < zone.shape[1]:
            z = int(zone[rr, cc]); zs.append(z if z > 0 else np.nan)
        else:
            zs.append(np.nan)
    sg["zone"] = zs
    v = sg.dropna(subset=["zone"]); v["zone"] = v["zone"].astype(int)
    n = len(v)
    obs = v["zone"].value_counts().reindex(range(1, 6), fill_value=0)

    print(f"\n=== {tag} — OSM solar validation (n={n}) ===")
    enr = {}
    for z in range(1, 6):
        ef = (obs[z] / n) / frac[z] if frac[z] > 0 else 0
        enr[z] = ef
        print(f"  Zone {z}: obs {obs[z]:>3} ({obs[z]/n*100:4.1f}%)  area {frac[z]*100:4.1f}%  enrich {ef:.2f}x")
    chi2, pchi, dof, _ = chi2_contingency(
        np.array([[obs[z], max(1, int(frac[z]*n))] for z in range(1, 6)]))
    print(f"  Zone1 precision={obs[1]/n:.3f}  Zone1+2={ (obs[1]+obs[2])/n*100:.1f}%  chi2={chi2:.1f} (p={pchi:.4f})")

    # province PAI rank vs plant count
    adm1 = next(l for l in fiona.listlayers(str(GADM)) if l.endswith("_1"))
    prov = gpd.read_file(str(GADM), layer=adm1)[["NAME_1", "geometry"]].to_crs("EPSG:4326")
    with rasterio.open(pai_tif) as s:
        nod = s.nodata
    prov["PAI"] = [z["mean"] for z in zonal_stats(prov, str(pai_tif), stats=["mean"], nodata=nod)]
    cnt = gpd.sjoin(v, prov, predicate="within").groupby("NAME_1").size()
    prov["plants"] = prov["NAME_1"].map(cnt).fillna(0)
    rho, p = spearmanr(prov["PAI"], prov["plants"])
    print(f"  Province PAI vs plant count: Spearman rho={rho:.3f} (p={p:.3f})")
    return enr

run(PROC / "DER_zones_90m.tif",         PROC / "PAI_90m.tif",         "NTL (published)")
run(PROC / "DER_zones_poverty_90m.tif", PROC / "PAI_poverty_90m.tif", "POVERTY (rerun)")
