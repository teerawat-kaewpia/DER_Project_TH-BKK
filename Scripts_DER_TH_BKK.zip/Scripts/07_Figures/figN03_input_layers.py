"""
Fig N03 — C1-C5 Input Criterion Layers (province-level choropleth)
==================================================================
Column mapping: CSV C1=Solar, C2=Poverty, C3=PopDens, C4=DROPPED,
                C5=GridDist(paper C4), C6=LandSuit(paper C5)
Output: Fig03_Input_Layers.png  (600 dpi)
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import geopandas as gpd
import fiona
import pandas as pd
from pathlib import Path
import os

BASE = Path(os.environ.get("DER_PROJECT_ROOT", Path(__file__).resolve().parents[2]))
PROC = BASE / "Data" / "14_Processed_90m"
GADM = BASE / "Data" / "01_Admin_Boundaries" / "gadm41_THA.gpkg"
OUT  = BASE / "Figures"

# ── Load ──────────────────────────────────────────────────────────────────────
layers = fiona.listlayers(str(GADM))
adm1   = next(l for l in layers if l.endswith("_1"))
prov   = gpd.read_file(str(GADM), layer=adm1)[["NAME_1","geometry"]].copy()
if prov.crs.to_epsg() != 4326:
    prov = prov.to_crs("EPSG:4326")

pai_df = pd.read_csv(PROC / "province_PAI_summary.csv")
prov   = prov.merge(pai_df, on="NAME_1", how="left")

# CSV column → paper label, colormap, description
CRIT = [
    ("C1",  "C1 — Resource Potential",     "YlOrRd",  "(Solar PVOUT, kWh/kWp/year)"),
    ("C2",  "C2 — Equity",                 "PuRd",    "(Official provincial poverty incidence)"),
    ("C3",  "C3 — Demand Density",         "YlOrBr",  "(WorldPop 2020)"),
    ("C5",  "C4 — Infrastructure Access",  "GnBu",    "(Grid proximity, exp(−d/5 km))"),
    ("C6",  "C5 — Physical Suitability",   "YlGn",    "(Hansen + slope + GHSL)"),
]

XLIM = (97.3, 105.7)
YLIM = (5.5,  20.6)

fig, axes = plt.subplots(1, 5, figsize=(17, 6.5), dpi=600, facecolor="white")
fig.subplots_adjust(wspace=0.06, top=0.97, bottom=0.05, left=0.02, right=0.98)

for ax, (col, title, cmap_name, desc) in zip(axes, CRIT):
    ax.set_aspect("equal")
    vmin = prov[col].quantile(0.02)
    vmax = prov[col].quantile(0.98)
    norm = mcolors.Normalize(vmin=vmin, vmax=vmax)
    cmap = plt.cm.get_cmap(cmap_name)

    prov.plot(ax=ax, column=col, cmap=cmap_name, norm=norm,
              edgecolor="#cccccc", linewidth=0.15)

    ax.set_xlim(*XLIM)
    ax.set_ylim(*YLIM)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.spines[:].set_visible(False)

    # Colorbar below each panel
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    cbar = fig.colorbar(sm, ax=ax, orientation="horizontal",
                        fraction=0.06, pad=0.02, shrink=0.80)
    cbar.ax.tick_params(labelsize=5.5)
    cbar.set_ticks([vmin, (vmin+vmax)/2, vmax])
    cbar.set_ticklabels([f"{vmin:.2f}", f"{(vmin+vmax)/2:.2f}", f"{vmax:.2f}"])

    ax.set_title(f"{title}\n{desc}", fontsize=7.5, pad=4, fontweight="bold")


fig.savefig(str(OUT / "Fig03_Input_Layers.png"), dpi=600, bbox_inches="tight")
print(f"Saved: {OUT / 'Fig03_Input_Layers.png'}")
plt.close()
print("=== Fig N03 COMPLETE ===")
