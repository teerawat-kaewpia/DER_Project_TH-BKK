# Per-Figure Notebooks

One runnable notebook per manuscript figure. Regenerate with `python _build_notebooks.py` after editing anything in `Scripts/07_Figures/` so the notebooks stay in step with the published images.

| Fig. | Notebook | Title | Output |
|---|---|---|---|
| 1 | `Fig01_Methodological_Framework.ipynb` | Methodological Framework | `Fig01_Framework.png` |
| 2 | `Fig02_Study_Area.ipynb` | Study Area | `Fig02_Study_Area.png` |
| 3 | `Fig03_Input_Criterion_Layers_C1_C5.ipynb` | Input Criterion Layers (C1-C5) | `Fig03_Input_Layers.png` |
| 4 | `Fig04_Criterion_Correlation_Matrix.ipynb` | Criterion Correlation Matrix | `Fig04_Correlation.png` |
| 5 | `Fig05_EWM_Criterion_Weights.ipynb` | EWM Criterion Weights | `Fig05_EWM_Weights.png` |
| 6 | `Fig06_Province_PAI_Choropleth.ipynb` | Province PAI Choropleth | `Fig06_PAI_Map.png` |
| 7 | `Fig07_Province_Priority_Zone_Map.ipynb` | Province Priority-Zone Map | `Fig07_Zone_Map.png` |
| 8 | `Fig08_LISA_Cluster_Map.ipynb` | LISA Cluster Map | `Fig08_LISA_Map.png` |
| 9 | `Fig09_Province_PAI_Ranking.ipynb` | Province PAI Ranking | `Fig09_Province_Ranking.png` |
| 10 | `Fig10_Deployment_Comparison_Scatter.ipynb` | Deployment Comparison Scatter | `Fig10_Validation_Scatter.png` |
| 11 | `Fig11_Sensitivity_Analysis.ipynb` | Sensitivity Analysis | `Fig11_Sensitivity.png` |
| 12 | `Fig12_Bangkok_District_PAI_and_Zones.ipynb` | Bangkok District PAI and Zones | `Fig12_Bangkok_District.png` |
| 13 | `Fig13_Zone_level_Criterion_Radar.ipynb` | Zone-level Criterion Radar | `Fig13_Radar.png` |
| 14 | `Fig14_Zone_to_Policy_Framework.ipynb` | Zone-to-Policy Framework | `Fig14_Policy.png` |
