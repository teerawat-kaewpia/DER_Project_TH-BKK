# -*- coding: utf-8 -*-
"""
Rebuild one .ipynb per manuscript figure from the current figure scripts.

Each notebook is self-contained and runnable: it carries the shared preamble of
its source script (imports + data loading) plus only the section that renders
that one figure. Multi-figure scripts are split on their "# FIG ..." markers.

Run this after any change to Scripts/07_Figures so the notebooks never drift
from the code that actually produced the published images.
"""
import json, re, nbformat as nbf
from pathlib import Path
import os

BASE = Path(os.environ.get("DER_PROJECT_ROOT", Path(__file__).resolve().parents[2]))
SRC  = BASE / "Scripts" / "07_Figures"
OUT  = BASE / "Scripts" / "10_Figure_Notebooks"
FIGD = BASE / "Figures"

# manuscript figure number -> (source script, marker regex or None, png, title)
SPEC = {
    1:  ("figN01_framework.py",            None,          "Fig01_Framework.png",          "Methodological Framework"),
    2:  ("figN02_study_area.py",           None,          "Fig02_Study_Area.png",         "Study Area"),
    3:  ("figN03_input_layers.py",         None,          "Fig03_Input_Layers.png",       "Input Criterion Layers (C1-C5)"),
    4:  ("figN04_05_corr_weights.py",      r"FIG N04",    "Fig04_Correlation.png",        "Criterion Correlation Matrix"),
    5:  ("figN04_05_corr_weights.py",      r"FIG N05",    "Fig05_EWM_Weights.png",        "EWM Criterion Weights"),
    6:  ("fig02_03_pai_zone_maps.py",      r"FIG 2",      "Fig06_PAI_Map.png",             "Province PAI Choropleth"),
    7:  ("fig02_03_pai_zone_maps.py",      r"FIG 3",      "Fig07_Zone_Map.png",            "Province Priority-Zone Map"),
    8:  ("fig04_lisa_map.py",              None,          "Fig08_LISA_Map.png",            "LISA Cluster Map"),
    9:  ("figN09_10_ranking_sensitivity.py", r"FIG N09",  "Fig09_Province_Ranking.png",   "Province PAI Ranking"),
    10: ("figN11_scatter.py",              None,          "Fig10_Validation_Scatter.png", "Deployment Comparison Scatter"),
    11: ("figN09_10_ranking_sensitivity.py", r"FIG N10",  "Fig11_Sensitivity.png",        "Sensitivity Analysis"),
    12: ("fig14_bangkok_district.py",      None,          "Fig12_Bangkok_District.png",   "Bangkok District PAI and Zones"),
    13: ("figN12_13_radar_policy.py",      r"FIG N12",    "Fig13_Radar.png",              "Zone-level Criterion Radar"),
    14: ("figN12_13_radar_policy.py",      r"FIG N13",    "Fig14_Policy.png",             "Zone-to-Policy Framework"),
}

MARKER = re.compile(r"^# ─+$", re.M)


def split_script(text):
    """Return (preamble, {marker_label: section_code}) for a marker-delimited script."""
    lines = text.splitlines()
    # locate marker headers: a rule line, a "# FIG ..." line, a rule line
    heads = [i for i, l in enumerate(lines)
             if l.startswith("# FIG") and i > 0 and lines[i - 1].startswith("# ──")]
    if not heads:
        return text, {}
    preamble = "\n".join(lines[:heads[0] - 1]).rstrip()
    sections = {}
    for k, h in enumerate(heads):
        end = heads[k + 1] - 1 if k + 1 < len(heads) else len(lines)
        sections[lines[h]] = "\n".join(lines[h - 1:end]).rstrip()
    return preamble, sections


def md(t):
    return nbf.v4.new_markdown_cell(t)


def code(t):
    return nbf.v4.new_code_cell(t)


written = []
for num, (script, marker, png, title) in sorted(SPEC.items()):
    text = (SRC / script).read_text(encoding="utf-8")
    preamble, sections = split_script(text)

    if marker:
        key = next((k for k in sections if re.search(marker, k)), None)
        if key is None:
            raise SystemExit(f"Fig {num}: marker {marker!r} not found in {script}")
        body = sections[key]
    else:
        preamble, body = "", text

    nb = nbf.v4.new_notebook()
    nb.cells.append(md(
        f"# Figure {num} — {title}\n\n"
        f"Reproduces **Fig. {num}** of the manuscript.\n\n"
        f"| | |\n|---|---|\n"
        f"| Source script | `Scripts/07_Figures/{script}` |\n"
        f"| Output image | `Figures/{png}` |\n"
        f"| Resolution | 600 dpi PNG (900 dpi TIFF produced separately) |\n\n"
        "Run the cells in order. Paths are absolute and resolve against the "
        "project data directory, so the notebook can be executed from anywhere."
    ))
    if preamble:
        nb.cells.append(md("## Setup: imports and data loading"))
        nb.cells.append(code(preamble))
        nb.cells.append(md("## Render the figure"))
    else:
        nb.cells.append(md("## Full figure script"))
    nb.cells.append(code(body))
    nb.cells.append(md("## Result"))
    nb.cells.append(code(
        "from IPython.display import Image, display\n"
        f'display(Image(filename=r"{FIGD / png}"))'
    ))

    nb.metadata["kernelspec"] = {"display_name": "Python 3", "language": "python", "name": "python3"}
    nb.metadata["language_info"] = {"name": "python"}

    safe = re.sub(r"[^A-Za-z0-9]+", "_", title).strip("_")
    path = OUT / f"Fig{num:02d}_{safe}.ipynb"
    nbf.write(nb, str(path))
    written.append((num, path.name, len(preamble.splitlines()), len(body.splitlines())))

# refresh README
rows = "\n".join(f"| {n} | `{f}` | {SPEC[n][3]} | `{SPEC[n][2]}` |" for n, f, _, _ in written)
(OUT / "README.md").write_text(
    "# Per-Figure Notebooks\n\n"
    "One runnable notebook per manuscript figure. Regenerate with "
    "`python _build_notebooks.py` after editing anything in `Scripts/07_Figures/` "
    "so the notebooks stay in step with the published images.\n\n"
    "| Fig. | Notebook | Title | Output |\n|---|---|---|---|\n" + rows + "\n",
    encoding="utf-8")

for n, f, p, b in written:
    print(f"  Fig {n:>2}  {f:<48} preamble {p:>3} lines, body {b:>3} lines")
print(f"\n{len(written)} notebooks + README written to {OUT}")
