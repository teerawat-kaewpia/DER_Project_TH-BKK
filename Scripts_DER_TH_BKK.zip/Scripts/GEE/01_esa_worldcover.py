
"""GEE: ESA WorldCover 2021 — LULC 10m → export at 90m"""
import ee; ee.Initialize()
from gee_setup import THAILAND, export_image, SCALE_90M

lulc = ee.ImageCollection("ESA/WorldCover/v200").first()

# Export 1: Original 10m (optional — large)
# export_image(lulc, 'ESA_WorldCover_2021_10m_Thailand', scale=10)

# Export 2: Resampled to 90m (recommended for research)
lulc_90m = lulc.reduceResolution(
    reducer=ee.Reducer.mode(), maxPixels=1024
).reproject(crs='EPSG:4326', scale=SCALE_90M)

export_image(lulc_90m, 'ESA_WorldCover_2021_90m_Thailand')

# Class legend:
# 10=Tree, 20=Shrubland, 30=Grassland, 40=Cropland
# 50=Built-up, 60=Bare/sparse, 70=Snow, 80=Open water
# 90=Herbaceous wetland, 95=Mangroves, 100=Moss/lichen
print('ESA WorldCover export queued → check GEE Tasks')
