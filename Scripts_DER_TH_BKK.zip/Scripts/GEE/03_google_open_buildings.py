
"""GEE: Google Open Buildings 2.5D Temporal — building height at 90m"""
import ee; ee.Initialize()
from gee_setup import THAILAND, export_image, SCALE_90M

# 2.5D Temporal: annual building height 2016-2023
ob_temporal = ee.ImageCollection(
    'GOOGLE/Research/open-buildings-temporal/v1'
).filterDate('2023-01-01', '2023-12-31').mosaic()

# Building height band
height = ob_temporal.select('building_height')
fraction = ob_temporal.select('building_fractional_count')
presence = ob_temporal.select('building_presence')

# Aggregate to 90m
for band_name, band in [('height', height),
                          ('fraction', fraction),
                          ('presence', presence)]:
    band_90m = band.reduceResolution(
        reducer=ee.Reducer.mean(), maxPixels=1024
    ).reproject(crs='EPSG:4326', scale=SCALE_90M)
    export_image(band_90m, f'GoogleOB_2_5D_{band_name}_2023_90m_Thailand')

# Also export v3 footprints as raster
ob_v3 = (ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons')
           .filterBounds(THAILAND))
ob_img = ob_v3.reduceToImage(['confidence'], ee.Reducer.mean())
export_image(ob_img, 'GoogleOB_v3_footprint_90m_Thailand')

print('Google Open Buildings export queued → GEE Tasks')
