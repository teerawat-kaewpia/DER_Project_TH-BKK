
"""GEE: ERA5-Land — annual mean climate variables"""
import ee; ee.Initialize()
from gee_setup import THAILAND, export_image

# Annual mean 2018-2023
era5 = (ee.ImageCollection('ECMWF/ERA5_LAND/MONTHLY_AGGR')
          .filterDate('2020-01-01', '2023-12-31')
          .select(['temperature_2m', 'u_component_of_wind_10m',
                   'v_component_of_wind_10m', 'surface_solar_radiation_downwards_sum'])
          .mean())

# Convert temperature K → °C
temp_c = era5.select('temperature_2m').subtract(273.15)

# Wind speed magnitude
u = era5.select('u_component_of_wind_10m')
v = era5.select('v_component_of_wind_10m')
wind_speed = u.pow(2).add(v.pow(2)).sqrt().rename('wind_speed_10m')

# ERA5 already at ~9km — export at 9000m (no resampling needed)
for name, img in [('temperature_2m_celsius', temp_c),
                   ('wind_speed_10m', wind_speed),
                   ('solar_radiation', era5.select('surface_solar_radiation_downwards_sum'))]:
    export_image(img, f'ERA5Land_annual_mean_{name}_Thailand', scale=9000)

print('ERA5-Land export queued → GEE Tasks')
