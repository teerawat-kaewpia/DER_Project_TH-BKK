
"""GEE: Sentinel-2 annual median composite — for LULC validation"""
import ee; ee.Initialize()
from gee_setup import THAILAND, export_image

def mask_s2_clouds(image):
    qa = image.select('QA60')
    cloud_bit = 1 << 10; cirrus_bit = 1 << 11
    mask = qa.bitwiseAnd(cloud_bit).eq(0).And(qa.bitwiseAnd(cirrus_bit).eq(0))
    return image.updateMask(mask).divide(10000)

s2 = (ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
        .filterDate('2022-01-01', '2023-12-31')
        .filterBounds(THAILAND)
        .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 20))
        .map(mask_s2_clouds)
        .select(['B2','B3','B4','B8','B11','B12'])
        .median())

# Export at 30m (aggregate from 10m)
s2_30m = s2.reproject(crs='EPSG:4326', scale=30)
export_image(s2_30m, 'Sentinel2_median_2022_2023_30m_Thailand', scale=30)

print('Sentinel-2 composite export queued → GEE Tasks')
