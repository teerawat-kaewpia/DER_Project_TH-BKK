
"""
Master GEE Runner — Thailand DER Research
Runs all export tasks sequentially

Prerequisites:
  pip install earthengine-api
  earthengine authenticate
"""
import ee; ee.Initialize()
import subprocess, sys

scripts = [
    '01_esa_worldcover.py',
    '02_viirs_nightlights.py',
    '03_google_open_buildings.py',
    '04_hansen_forest.py',
    '05_copernicus_dem.py',
    '06_era5_climate.py',
    '07_sentinel2.py',
]

for script in scripts:
    print(f'\n{'='*50}')
    print(f'Running: {script}')
    subprocess.run([sys.executable, script], check=True)

print('\n✓ All GEE exports queued!')
print('→ Check: code.earthengine.google.com → Tasks tab')
print('→ Files appear in: Google Drive / DER_Thailand_Research/')
