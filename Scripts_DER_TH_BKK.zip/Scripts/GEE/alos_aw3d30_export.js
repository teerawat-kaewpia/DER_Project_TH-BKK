// ALOS AW3D30 DSM export for Thailand at 90m.
// Paste this whole file into code.earthengine.google.com and click Run.
//
// Purpose: export ALOS AW3D30 V3.2 DSM (Digital Surface Model) at 90m so it can
// be subtracted from Copernicus GLO-30 DEM to produce a normalized DSM (nDSM),
// which approximates above-ground height (buildings + vegetation).
// Vegetation is masked out in a separate local Python step using Hansen treecover.
//
// Output -> Google Drive / DER_Thailand_DEM folder:
//   Thailand_ALOS_AW3D30_DSM_90m_Thailand.tif
//
// NOTE: keep this file pure ASCII.

var THAILAND = ee.Geometry.Rectangle([97.0, 5.0, 106.5, 21.5]);
var SCALE_90M = 90;
var CRS = 'EPSG:4326';
var EXPORT_FOLDER = 'DER_Thailand_DEM';
var MAX_PIXELS = 5e8;

// ALOS World 3D AW3D30 V3.2 -- ImageCollection of 1x1 degree tiles.
// Band 'DSM': ellipsoidal height in metres above WGS84 ellipsoid.
// Native resolution 30m (1 arc-second); exported here at 90m (3 arc-sec)
// to match the Copernicus GLO-30 DEM already preprocessed in Energy map\.
var alos = ee.ImageCollection('JAXA/ALOS/AW3D30/V3_2')
  .filterBounds(THAILAND)
  .select('DSM')
  .mosaic();

Export.image.toDrive({
  image: alos.clip(THAILAND),
  description: 'Thailand_ALOS_AW3D30_DSM_90m',
  folder: EXPORT_FOLDER,
  fileNamePrefix: 'Thailand_ALOS_AW3D30_DSM_90m',
  scale: SCALE_90M,
  crs: CRS,
  region: THAILAND,
  maxPixels: MAX_PIXELS,
  fileFormat: 'GeoTIFF'
});

// Quick visual check
Map.centerObject(THAILAND, 6);
Map.addLayer(alos.clip(THAILAND), {min: 0, max: 2500, palette: ['006633','E5FFCC','662A00','D8D8D8','F5F5F5']}, 'ALOS DSM');
print('Export queued: Thailand_ALOS_AW3D30_DSM_90m -> Drive/' + EXPORT_FOLDER);
print('After export, run DER/Scripts/02_Preprocessing/compute_ndsm.py to produce nDSM and building height layer.');
