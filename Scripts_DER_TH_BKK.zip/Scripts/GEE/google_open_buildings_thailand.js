// Google Open Buildings (2.5D Temporal + v3 footprints) for Thailand, aggregated to 90m.
// Paste this whole file into code.earthengine.google.com and click Run.
// No local "earthengine authenticate" needed - browser login is enough.
// Equivalent to DER/Scripts/GEE/03_google_open_buildings.py, ported to JS so it
// can run directly in the Code Editor instead of being blocked on local Python auth.
//
// NOTE: keep this file pure ASCII. A non-ASCII em-dash broke the GEE JS parser
// once before (see sentinel2_composite_thailand.js history) - do not paste
// curly quotes / em-dashes / Thai text into this file.

var THAILAND = ee.Geometry.Rectangle([97.5, 5.5, 105.7, 20.5]);
var SCALE_90M = 90;
var CRS = 'EPSG:4326';
var EXPORT_FOLDER = 'DER_Thailand_Buildings';

// Thailand bbox area is about 1.48e12 m^2 -> ~1.8e8 pixels at 90m.
// Cap maxPixels well above that but far below an unbounded value, same fix
// applied to the Sentinel-2 script to avoid worker-timeout retries burning EECU.
var MAX_PIXELS = 5e8;

// ---------------------------------------------------------
//  UI panel: same date-range pattern as sentinel2_composite_thailand.js
//  so the year/period can be changed in the Code Editor without editing code.
//  open-buildings-temporal/v1 covers 2016-2023.
// ---------------------------------------------------------
var Header = ui.Label('Google Open Buildings - Thailand', {fontWeight: 'bold', fontSize: '20px', textAlign: 'center'});

var Subheader1 = ui.Label('Temporal building layer period (within 2016-2023):', {fontWeight: 'bold'});
var label_Start_date_select = ui.Label('Start:');
var Start_date_select = ui.Textbox({
  value: '2023-01-01',
  style: {width: '90px'}
});
var label_End_date_select = ui.Label('End:');
var End_date_select = ui.Textbox({
  value: '2023-12-31',
  style: {width: '90px', textAlign: 'right'}
});

var panel = ui.Panel({
  widgets: [Header, Subheader1, label_Start_date_select, Start_date_select, label_End_date_select, End_date_select],
  style: {position: 'top-left', width: '220px'}
});
ui.root.add(panel);

function exportImage(image, name) {
  Export.image.toDrive({
    image: image.clip(THAILAND),
    description: name,
    folder: EXPORT_FOLDER,
    fileNamePrefix: name,
    scale: SCALE_90M,
    crs: CRS,
    region: THAILAND,
    maxPixels: MAX_PIXELS,
    fileFormat: 'GeoTIFF'
  });
  print('Export queued: ' + name);
}

function RunBuildingsExport() {
  Map.clear();
  AddButton();

  var start_date = Start_date_select.getValue();
  var end_date = End_date_select.getValue();
  print('Running Open Buildings export for ' + start_date + ' to ' + end_date);

  // ---- 2.5D Temporal: annual building height / fraction / presence ----
  var obCollection = ee.ImageCollection('GOOGLE/Research/open-buildings-temporal/v1')
    .filterDate(start_date, end_date)
    .filterBounds(THAILAND);
  // Dataset only covers 2016-2023 - print the match count so a wrong/out-of-range
  // date (e.g. 2024+) shows up as "0 images found" instead of a cryptic
  // "Image.select ... no bands" error further down.
  print('Open Buildings images found for ' + start_date + ' to ' + end_date + ':', obCollection.size());
  // Source tiles each carry their own native projection (often different UTM
  // zones per tile), so mosaic()-ing raw tiles first and borrowing one tile's
  // projection for the whole bbox is invalid - it breaks as soon as the export
  // touches a region covered by a different tile ("does not have a valid
  // default projection"). Fix: reduceResolution+reproject EACH source image
  // individually (where its own native projection is always valid), then
  // mosaic the already-90m-aligned tiles together.
  var yearTag = start_date.slice(0, 4);

  var bandNames = ['building_height', 'building_fractional_count', 'building_presence'];
  var outNames = ['height', 'fraction', 'presence'];

  for (var i = 0; i < bandNames.length; i++) {
    var band90mCollection = obCollection.select([bandNames[i]]).map(function(img) {
      // Calling .reproject() here as a standalone script-level op forces GEE
      // to materialize the FULL reprojected grid eagerly, regardless of any
      // .clip() applied first - that's what threw "Reprojection output too
      // large" even after clipping to Thailand. Fix: do the reduceResolution
      // aggregation (which "remembers" how to downsample) but do NOT
      // reproject here. Each tile keeps its own native projection; mosaic()
      // can combine differently-projected tiles fine (it samples each one
      // lazily at request time). The actual reprojection to EPSG:4326/90m
      // happens inside Export.image.toDrive's own crs/scale/region, which is
      // a bounded, tiled batch job instead of an eager whole-image op.
      var clipped = img.clip(THAILAND);
      // Source pixels are ~0.5m native resolution, so a 90m output pixel
      // needs ~32,010 input pixels (90/0.5)^2 - far above the old maxPixels:
      // 1024 cap ("Too many input pixels per output pixel"). 65536 is GEE's
      // documented ceiling for reduceResolution's maxPixels, used here for
      // margin above the ~32k actually needed.
      return clipped.reduceResolution({
        reducer: ee.Reducer.mean(),
        maxPixels: 65536
      });
    });
    var band90m = band90mCollection.mosaic();
    exportImage(band90m, 'GoogleOB_2_5D_' + outNames[i] + '_' + yearTag + '_90m_Thailand');
  }

  // for the map preview only - cheap, doesn't need the per-tile reprojection
  var height = obCollection.select(['building_height']).mosaic();

  // ---- v3 footprints, rasterized at 90m (not time-filtered, single static layer) ----
  var obV3 = ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons')
    .filterBounds(THAILAND);
  var obImg = obV3.reduceToImage(['confidence'], ee.Reducer.mean());
  exportImage(obImg, 'GoogleOB_v3_footprint_90m_Thailand');

  // ---- quick visual sanity check ----
  Map.centerObject(THAILAND, 6);
  Map.addLayer(height.clip(THAILAND), {min: 0, max: 30, palette: ['white', 'orange', 'red']}, 'building_height_' + yearTag, 0);

  print('4 Google Open Buildings export tasks queued. Go to the Tasks tab and click RUN on each.');
}

function AddButton() {
  var button = ui.Button('Run Open Buildings Export (Thailand)');
  button.style().set({
    position: 'top-center',
    border: '1px solid #000000'
  });
  button.onClick(function() {
    return RunBuildingsExport();
  });
  Map.add(button);
}

AddButton();
