/**
 * Google Open Buildings 2.5D Temporal -> fraction & height, Bangkok (50 khet)
 * ==========================================================================
 * Companion to run_bangkok_buildings_export.js (which produced the 30 m
 * building-PRESENCE layer). This adds the two continuous 2.5D Temporal bands
 * the presence layer does not carry:
 *   building_fractional_count  -> a finer rooftop-density C5 proxy than binary
 *                                 presence (sub-cell building fraction)
 *   building_height            -> mean building height (informs rooftop area /
 *                                 shading, useful context, not a core criterion)
 *
 * Why the earlier 2.5D attempts failed ("Reprojection output too large
 * 15030x15368"): a mosaic() of the collection carries the DEFAULT 1-degree
 * projection, so when reduceResolution/reproject ran, GEE first tried to
 * render the input at its ~4 m native grid over the WHOLE bbox (15030x15368
 * px) -> cap. Fix: pin the input to its true native projection with
 * setDefaultProjection() BEFORE reduceResolution, so GEE aggregates ~4 m
 * native pixels straight into 30 m output cells and only ever materialises the
 * 30 m result (~2232x1714 = 3.8M px, far under the cap). No tiling needed.
 *
 * Outputs (Drive -> DER_Bangkok_Buildings/):
 *   GoogleOB_2_5D_fraction_2023_30m_Bangkok.tif
 *   GoogleOB_2_5D_height_2023_30m_Bangkok.tif
 *
 * Usage:
 *   1. Paste into a new script at code.earthengine.google.com
 *   2. Click "Run" -- check "native scale (m)" printed to Console (~4 m
 *      expected) and inspect the two map layers
 *   3. Open the "Tasks" tab, click "RUN" on both tasks
 *   4. Download from Drive -> DER_Bangkok_Buildings/ into:
 *      D:\Clude Code GIS\Energy\DER\Data\07_Buildings\Bangkok\
 */

// ---- config ----
var START_DATE = '2023-01-01';
var END_DATE   = '2023-12-31';
var BANGKOK    = ee.Geometry.Rectangle([100.3200, 13.4925, 100.9391, 13.9543]);
var CRS        = 'EPSG:4326';
var SCALE_30M  = 30;
var MAX_PIXELS = 5e8;
var FOLDER     = 'DER_Bangkok_Buildings';
var YEAR_TAG   = START_DATE.slice(0, 4);

// ---- load 2.5D Temporal, pin native projection ----
var col = ee.ImageCollection('GOOGLE/Research/open-buildings-temporal/v1')
    .filterDate(START_DATE, END_DATE)
    .filterBounds(BANGKOK);

print('2.5D images for', START_DATE, 'to', END_DATE, ':', col.size());

// native projection of the source (~4 m); reduceResolution needs this so it
// does NOT fall back to reprojecting a 1-degree mosaic over the full bbox.
var nativeProj = col.first().projection();
print('native scale (m):', nativeProj.nominalScale());

var bands    = ['building_fractional_count', 'building_height'];
var outNames = ['fraction', 'height'];

// mosaic (spatial tiles), declare native projection, then areal-mean to 30 m
var img30 = col.select(bands).mosaic()
    .setDefaultProjection(nativeProj)
    .reduceResolution({
      reducer: ee.Reducer.mean(),
      maxPixels: 1024,
      bestEffort: true
    })
    .reproject({crs: CRS, scale: SCALE_30M})
    .clip(BANGKOK);

// ---- visual sanity check ----
Map.centerObject(BANGKOK, 11);
Map.addLayer(img30.select('building_fractional_count'),
    {min: 0, max: 1, palette: ['ffffff', 'fee090', 'd73027']},
    'Building fraction 30m');
Map.addLayer(img30.select('building_height'),
    {min: 0, max: 30, palette: ['ffffff', '91bfdb', '4575b4']},
    'Building height 30m', false);

// ---- export both bands ----
for (var i = 0; i < bands.length; i++) {
  var name = 'GoogleOB_2_5D_' + outNames[i] + '_' + YEAR_TAG + '_' + SCALE_30M + 'm_Bangkok';
  Export.image.toDrive({
    image: img30.select([bands[i]]),
    description: name,
    folder: FOLDER,
    fileNamePrefix: name,
    scale: SCALE_30M,
    crs: CRS,
    region: BANGKOK,
    maxPixels: MAX_PIXELS,
    fileFormat: 'GeoTIFF'
  });
  print('Queued:', name);
}
print('2 export tasks queued -- open the Tasks tab and click RUN on each.');
