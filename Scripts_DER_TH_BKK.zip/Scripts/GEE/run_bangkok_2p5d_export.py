# -*- coding: utf-8 -*-
"""
Google Open Buildings 2.5D Temporal -> fraction & height, Bangkok (50 khet).
Python / command-line twin of run_bangkok_2p5d_export.js.

Companion to run_bangkok_buildings_export.py (30 m building PRESENCE). Adds the
two continuous 2.5D Temporal bands presence does not carry:
  building_fractional_count -> finer rooftop-density C5 proxy (sub-cell fraction)
  building_height           -> mean building height (context; not a core criterion)

Why the earlier 2.5D attempts failed ("Reprojection output too large
15030x15368"): a mosaic() of the collection carries the DEFAULT 1-degree
projection, so reduceResolution/reproject first tried to render the input at
its ~4 m native grid over the WHOLE bbox (15030x15368 px) -> cap. Fix: pin the
input to its true native projection with setDefaultProjection() BEFORE
reduceResolution, so GEE aggregates ~4 m native pixels straight into 30 m
output cells and only materialises the 30 m result (~2232x1714 = 3.8M px, far
under the cap). No tiling needed.

Outputs (Drive -> DER_Bangkok_Buildings/):
  GoogleOB_2_5D_fraction_2023_30m_Bangkok.tif
  GoogleOB_2_5D_height_2023_30m_Bangkok.tif

Usage:
  1) earthengine authenticate      (one-time)
  2) python run_bangkok_2p5d_export.py
  3) Download from Drive -> DER_Bangkok_Buildings/ into:
     D:\\Clude Code GIS\\Energy\\DER\\Data\\07_Buildings\\Bangkok\\
"""

import time
import ee

# ---- config ----
PROJECT    = 'ee-teerawat'
START_DATE = '2023-01-01'
END_DATE   = '2023-12-31'
BANGKOK    = ee.Geometry.Rectangle([100.3200, 13.4925, 100.9391, 13.9543])
CRS        = 'EPSG:4326'
SCALE_30M  = 30
MAX_PIXELS = 5e8
FOLDER     = 'DER_Bangkok_Buildings'
YEAR_TAG   = START_DATE[:4]

BANDS     = ['building_fractional_count', 'building_height']
OUT_NAMES = ['fraction', 'height']


def submit_tasks():
    ee.Initialize(project=PROJECT)
    print(f'GEE initialized (project={PROJECT})')

    col = (ee.ImageCollection('GOOGLE/Research/open-buildings-temporal/v1')
           .filterDate(START_DATE, END_DATE)
           .filterBounds(BANGKOK))
    n = col.size().getInfo()
    print(f'2.5D images for {START_DATE} to {END_DATE}: {n}')
    if n == 0:
        raise RuntimeError('No images found -- dataset covers 2016-2023 only')

    # native projection of the source (~4 m); reduceResolution needs this so it
    # does NOT fall back to reprojecting a 1-degree mosaic over the full bbox.
    native_proj = col.first().projection()
    print(f'native scale (m): {native_proj.nominalScale().getInfo():.2f}')

    # mosaic (spatial tiles), declare native projection, areal-mean to 30 m
    img30 = (col.select(BANDS).mosaic()
             .setDefaultProjection(native_proj)
             .reduceResolution(reducer=ee.Reducer.mean(),
                               maxPixels=1024, bestEffort=True)
             .reproject(crs=CRS, scale=SCALE_30M)
             .clip(BANGKOK))

    tasks = []
    for band, out in zip(BANDS, OUT_NAMES):
        name = f'GoogleOB_2_5D_{out}_{YEAR_TAG}_{SCALE_30M}m_Bangkok'
        task = ee.batch.Export.image.toDrive(
            image=img30.select([band]),
            description=name,
            folder=FOLDER,
            fileNamePrefix=name,
            scale=SCALE_30M,
            crs=CRS,
            region=BANGKOK,
            maxPixels=int(MAX_PIXELS),
            fileFormat='GeoTIFF',
        )
        task.start()
        tasks.append((name, task))
        print(f'  Queued: {name}')
    return tasks


def wait_for_tasks(tasks, poll_seconds=30):
    print(f'\nWaiting for {len(tasks)} export task(s) to complete...')
    pending = list(tasks)
    while pending:
        still_pending = []
        for name, task in pending:
            status = task.status()
            state  = status['state']
            if state == 'COMPLETED':
                print(f'  DONE:    {name}')
            elif state == 'FAILED':
                print(f'  FAILED:  {name}  error={status.get("error_message","?")}')
            elif state in ('CANCEL_REQUESTED', 'CANCELLED'):
                print(f'  CANCELLED: {name}')
            else:
                still_pending.append((name, task))
        pending = still_pending
        if pending:
            names = ', '.join(n for n, _ in pending)
            print(f'  [{time.strftime("%H:%M:%S")}] Still running: {names}')
            time.sleep(poll_seconds)

    print('\nAll tasks finished.')
    print(f'Download from Google Drive -> {FOLDER}/')
    print('Place in: D:\\Clude Code GIS\\Energy\\DER\\Data\\07_Buildings\\Bangkok\\')


if __name__ == '__main__':
    tasks = submit_tasks()
    wait_for_tasks(tasks)
