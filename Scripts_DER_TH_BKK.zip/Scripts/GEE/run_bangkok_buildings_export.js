/**
 * Google Open Buildings v3 -> building presence, Bangkok Metropolitan Region
 * ==========================================================================
 * For use directly in the Earth Engine Code Editor (code.earthengine.google.com).
 *
 * Purpose: a district-scale C5 "physical suitability" proxy (rooftop
 * availability) for Bangkok's 50 khet. A feasibility probe showed the national
 * 90 m land-suitability raster saturates near 1.0 for all 50 khet (CV = 0.4%),
 * so it cannot discriminate between districts. This re-derives a built-up
 * layer from Open Buildings footprints at 30 m instead.
 *
 * Why so simple (after several "Reprojection output too large" failures):
 *   The earlier attempts rasterized footprints at their ~4 m NATIVE resolution
 *   over the whole Bangkok bbox (15030 x 15368 px) via reduceResolution +
 *   reproject -- which blows past GEE's per-reprojection cap. But we never
 *   needed a fine raster: the analysis only consumes the DISTRICT MEAN. So we
 *   paint the footprint polygons straight onto the 30 m export grid. Any 30 m
 *   cell touched by a building = 1, else 0. Full bbox at 30 m is only
 *   ~2232 x 1714 = 3.8M px -- far under the cap. No fine reproject, no
 *   reduceResolution, no tiling.
 *
 *   District mean of this presence layer = built-up fraction per khet, which
 *   IS the discriminating C5 signal (expected CV ~20-30%, vs 0.4% before).
 *
 * Output (Drive -> DER_Bangkok_Buildings/):
 *   GoogleOB_v3_presence_30m_Bangkok.tif   (0/1 building presence at 30 m)
 *
 * Usage:
 *   1. Paste this whole file into a new script at code.earthengine.google.com
 *   2. Click "Run" -- inspect the "Building presence 30m" layer on the map
 *   3. Open the "Tasks" tab (top-right), click "RUN" on the single task
 *   4. Download from Google Drive -> DER_Bangkok_Buildings/ into:
 *      D:\Clude Code GIS\Energy\DER\Data\07_Buildings\Bangkok\
 *   5. Locally: clip to the 50 khet (GADM ADM2) and take the district mean
 *      -> C5 proxy (same rasterio zonal-stats workflow as the province run)
 */

// ---- config ----
// Bangkok Metropolitan Region bbox (50 khet, GADM ADM2 NAME_1 == 'Bangkok Metropolis')
var BANGKOK   = ee.Geometry.Rectangle([100.3200, 13.4925, 100.9391, 13.9543]);
var CRS       = 'EPSG:4326';
var SCALE_30M = 30;
var MAX_PIXELS = 5e8;
var FOLDER    = 'DER_Bangkok_Buildings';

// ---- build the 30 m presence layer ----
var obV3 = ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons')
    .filterBounds(BANGKOK);

// paint() rasterizes the footprint polygons at whatever grid the downstream
// op requests -- here, the 30 m export grid set by reproject(). No fine native
// render is ever materialised, so the reprojection cap is not hit.
var built30m = ee.Image().byte().paint(obV3, 1).unmask(0)
    .reproject({crs: CRS, scale: SCALE_30M})
    .rename('building_presence')
    .clip(BANGKOK);

// ---- visual sanity check ----
Map.centerObject(BANGKOK, 11);
Map.addLayer(BANGKOK, {color: 'red'}, 'Bangkok bbox', false);
Map.addLayer(built30m,
    {min: 0, max: 1, palette: ['ffffff', 'd73027']},
    'Building presence 30m');

// ---- export ----
var name = 'GoogleOB_v3_presence_' + SCALE_30M + 'm_Bangkok';
Export.image.toDrive({
  image: built30m,
  description: name,
  folder: FOLDER,
  fileNamePrefix: name,
  scale: SCALE_30M,
  crs: CRS,
  region: BANGKOK,
  maxPixels: MAX_PIXELS,
  fileFormat: 'GeoTIFF'
});
print('Queued:', name, '-- open the Tasks tab and click RUN.');
