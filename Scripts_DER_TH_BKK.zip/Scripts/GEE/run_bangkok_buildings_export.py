# -*- coding: utf-8 -*-
"""
Google Open Buildings v3 -> building presence, Bangkok Metropolitan Region.
Python / command-line twin of run_bangkok_buildings_export.js.

Purpose: a district-scale C5 "physical suitability" proxy (rooftop
availability) for Bangkok's 50 khet. A feasibility probe showed the national
90 m land-suitability raster saturates near 1.0 for all 50 khet (CV = 0.4%),
so it cannot discriminate between districts. This re-derives a built-up layer
from Open Buildings footprints at 30 m instead.

Why so simple (after several "Reprojection output too large" failures):
  The earlier attempts rasterized footprints at their ~4 m NATIVE resolution
  over the whole Bangkok bbox (15030 x 15368 px) via reduceResolution +
  reproject -- which blows past GEE's per-reprojection cap. But we never
  needed a fine raster: the analysis only consumes the DISTRICT MEAN. So we
  paint the footprint polygons straight onto the 30 m export grid. Any 30 m
  cell touched by a building = 1, else 0. Full bbox at 30 m is only
  ~2232 x 1714 = 3.8M px -- far under the cap. No fine reproject, no
  reduceResolution, no tiling.

Output (Drive -> DER_Bangkok_Buildings/):
  GoogleOB_v3_presence_30m_Bangkok.tif   (0/1 building presence at 30 m)

Usage:
  1) earthengine authenticate      (one-time, opens browser for Google login)
  2) python run_bangkok_buildings_export.py
  3) Download from Google Drive -> DER_Bangkok_Buildings/ into:
     D:\\Clude Code GIS\\Energy\\DER\\Data\\07_Buildings\\Bangkok\\
  4) Locally: clip to the 50 khet (GADM ADM2) and take the district mean
     -> C5 proxy (same rasterio zonal-stats workflow as the province run)
"""

import time
import ee

# ---- config ----
PROJECT    = 'ee-teerawat'
# Bangkok Metropolitan Region bbox (50 khet, GADM ADM2 NAME_1 == 'Bangkok Metropolis')
BANGKOK    = ee.Geometry.Rectangle([100.3200, 13.4925, 100.9391, 13.9543])
CRS        = 'EPSG:4326'
SCALE_30M  = 30
MAX_PIXELS = 5e8
FOLDER     = 'DER_Bangkok_Buildings'


def submit_tasks():
    ee.Initialize(project=PROJECT)
    print(f'GEE initialized (project={PROJECT})')

    obV3 = (ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons')
            .filterBounds(BANGKOK))

    # paint() rasterizes the footprint polygons at whatever grid the downstream
    # op requests -- here, the 30 m export grid set by reproject(). No fine
    # native render is materialised, so the reprojection cap is not hit.
    built_30m = (ee.Image().byte().paint(obV3, 1).unmask(0)
                 .reproject(crs=CRS, scale=SCALE_30M)
                 .rename('building_presence')
                 .clip(BANGKOK))

    name = f'GoogleOB_v3_presence_{SCALE_30M}m_Bangkok'
    task = ee.batch.Export.image.toDrive(
        image=built_30m,
        description=name,
        folder=FOLDER,
        fileNamePrefix=name,
        scale=SCALE_30M,
        crs=CRS,
        region=BANGKOK,
        maxPixels=int(MAX_PIXELS),
        fileFormat='GeoTIFF',
    )
    task.start()
    print(f'  Queued: {name}')
    return [(name, task)]


def wait_for_tasks(tasks, poll_seconds=30):
    print(f'\nWaiting for {len(tasks)} export task(s) to complete...')
    pending = list(tasks)
    while pending:
        still_pending = []
        for name, task in pending:
            status = task.status()
            state  = status['state']
            if state == 'COMPLETED':
                print(f'  DONE:    {name}')
            elif state == 'FAILED':
                print(f'  FAILED:  {name}  error={status.get("error_message","?")}')
            elif state in ('CANCEL_REQUESTED', 'CANCELLED'):
                print(f'  CANCELLED: {name}')
            else:
                still_pending.append((name, task))
        pending = still_pending
        if pending:
            names = ', '.join(n for n, _ in pending)
            print(f'  [{time.strftime("%H:%M:%S")}] Still running: {names}')
            time.sleep(poll_seconds)

    print('\nAll tasks finished.')
    print(f'Download from Google Drive -> {FOLDER}/')
    print('Place in: D:\\Clude Code GIS\\Energy\\DER\\Data\\07_Buildings\\Bangkok\\')


if __name__ == '__main__':
    tasks = submit_tasks()
    wait_for_tasks(tasks)
