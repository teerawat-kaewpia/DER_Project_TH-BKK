/**
 * Google Open Buildings v3 -> footprint DENSITY (coverage fraction), Bangkok
 * ==========================================================================
 * Third and finest of the Bangkok building layers:
 *   presence (run_bangkok_buildings_export.js) : v3 paint @30 m, binary 0/1
 *   density  (THIS script)                     : v3 paint @5 m -> mean @30 m,
 *                                                = fraction of each 30 m cell
 *                                                  actually covered by building
 *                                                  footprint (continuous 0-1)
 *   fraction/height (run_bangkok_2p5d_export.js): the 2.5D Temporal bands
 *
 * "Density" is the truest C5 rooftop-availability proxy: not just "is there a
 * building in this cell" (presence) but "how much of the cell is roof".
 *
 * Why this no longer hits "Reprojection output too large (15030x15368)":
 * paint() is rasterised at 5 m ONLY where the 30 m output is requested.
 * setDefaultProjection(..,5) declares the input granularity, then
 * reduceResolution averages the 5 m footprint cells into each 30 m output
 * cell -- GEE tiles that work by the 30 m output (256x256), so only ~3.8M px
 * of 30 m result is ever materialised. No full-bbox 5 m render, no tiling.
 * (36 5 m sub-cells per 30 m cell << maxPixels; bestEffort is a safety net.)
 *
 * Output (Drive -> DER_Bangkok_Buildings/):
 *   GoogleOB_v3_density_30m_Bangkok.tif   (footprint coverage fraction, 0-1)
 *
 * Usage:
 *   1. Paste into a new script at code.earthengine.google.com
 *   2. Click "Run" -- inspect the "Building density (coverage) 30m" layer
 *   3. Open the "Tasks" tab, click "RUN" on the single task
 *   4. Download from Drive -> DER_Bangkok_Buildings/ into:
 *      D:\Clude Code GIS\Energy\DER\Data\07_Buildings\Bangkok\
 */

// ---- config ----
var BANGKOK    = ee.Geometry.Rectangle([100.3200, 13.4925, 100.9391, 13.9543]);
var CRS        = 'EPSG:4326';
var SCALE_30M  = 30;
var FINE_SCALE = 5;    // granularity at which footprints are rasterised
var MAX_PIXELS = 5e8;
var FOLDER     = 'DER_Bangkok_Buildings';

// ---- build the coverage-fraction layer ----
var obV3 = ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons')
    .filterBounds(BANGKOK);

// paint footprints, DECLARE 5 m granularity, then areal-mean to 30 m.
// setDefaultProjection is what lets reduceResolution aggregate 5 m -> 30 m
// per output tile instead of rendering the whole 5 m grid at once.
var density30m = ee.Image().byte().paint(obV3, 1).unmask(0)
    .setDefaultProjection(CRS, null, FINE_SCALE)
    .reduceResolution({
      reducer: ee.Reducer.mean(),
      maxPixels: 1024,
      bestEffort: true
    })
    .reproject({crs: CRS, scale: SCALE_30M})
    .rename('building_density')
    .clip(BANGKOK);

// ---- visual sanity check ----
Map.centerObject(BANGKOK, 11);
Map.addLayer(BANGKOK, {color: 'red'}, 'Bangkok bbox', false);
Map.addLayer(density30m,
    {min: 0, max: 1, palette: ['ffffff', 'fee090', 'fc8d59', 'd73027']},
    'Building density (coverage) 30m');

// ---- export ----
var name = 'GoogleOB_v3_density_' + SCALE_30M + 'm_Bangkok';
Export.image.toDrive({
  image: density30m,
  description: name,
  folder: FOLDER,
  fileNamePrefix: name,
  scale: SCALE_30M,
  crs: CRS,
  region: BANGKOK,
  maxPixels: MAX_PIXELS,
  fileFormat: 'GeoTIFF'
});
print('Queued:', name, '-- open the Tasks tab and click RUN.');
