# -*- coding: utf-8 -*-
"""
Submit Google Open Buildings export tasks to GEE and wait for completion.
Equivalent to pasting google_open_buildings_thailand.js into the Code Editor
and clicking Run + Tasks > RUN, but runs entirely from Python.

Outputs (Google Drive -> DER_Thailand_Buildings/):
  GoogleOB_2_5D_height_2023_90m_Thailand.tif
  GoogleOB_2_5D_fraction_2023_90m_Thailand.tif
  GoogleOB_2_5D_presence_2023_90m_Thailand.tif
  GoogleOB_v3_footprint_90m_Thailand.tif

Run once after `earthengine authenticate` has been completed.
"""

import time
import ee

# ---- config ----
PROJECT      = 'ee-teerawat'
START_DATE   = '2023-01-01'
END_DATE     = '2023-12-31'
THAILAND     = ee.Geometry.Rectangle([97.5, 5.5, 105.7, 20.5])
CRS          = 'EPSG:4326'
SCALE_90M    = 90
MAX_PIXELS   = 5e8
FOLDER       = 'DER_Thailand_Buildings'

BAND_NAMES = ['building_height', 'building_fractional_count', 'building_presence']
OUT_NAMES  = ['height', 'fraction', 'presence']
YEAR_TAG   = START_DATE[:4]


def submit_tasks():
    ee.Initialize(project=PROJECT)
    print(f'GEE initialized (project={PROJECT})')

    # ---- 2.5D Temporal: per-band, per-tile reduceResolution then mosaic ----
    ob_collection = (ee.ImageCollection('GOOGLE/Research/open-buildings-temporal/v1')
                     .filterDate(START_DATE, END_DATE)
                     .filterBounds(THAILAND))
    n = ob_collection.size().getInfo()
    print(f'Open Buildings images found for {START_DATE} to {END_DATE}: {n}')
    if n == 0:
        raise RuntimeError('No images found -- check date range (dataset covers 2016-2023 only)')

    tasks = []

    for band, out in zip(BAND_NAMES, OUT_NAMES):
        def make_reduced(img, _band=band):
            clipped = img.clip(THAILAND)
            # reduceResolution "remembers" aggregation method per source tile
            # (each tile has its own valid native projection).
            # No .reproject() here -- eager whole-image reproject caused
            # "Reprojection output too large" even after clipping.
            # The actual CRS/scale conversion is done by Export.image.toDrive
            # (bounded batch job, not eager script-level op).
            return clipped.reduceResolution(
                reducer=ee.Reducer.mean(),
                maxPixels=65536   # (90/0.5)^2 = ~32400 needed; 65536 is GEE ceiling
            ).select([_band])

        band_mosaic = ob_collection.select([band]).map(make_reduced).mosaic()
        name = f'GoogleOB_2_5D_{out}_{YEAR_TAG}_90m_Thailand'
        task = ee.batch.Export.image.toDrive(
            image=band_mosaic.clip(THAILAND),
            description=name,
            folder=FOLDER,
            fileNamePrefix=name,
            scale=SCALE_90M,
            crs=CRS,
            region=THAILAND,
            maxPixels=int(MAX_PIXELS),
            fileFormat='GeoTIFF',
        )
        task.start()
        tasks.append((name, task))
        print(f'  Queued: {name}')

    # ---- v3 footprints rasterized ----
    ob_v3 = ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons').filterBounds(THAILAND)
    ob_img = ob_v3.reduceToImage(['confidence'], ee.Reducer.mean())
    name_v3 = 'GoogleOB_v3_footprint_90m_Thailand'
    task_v3 = ee.batch.Export.image.toDrive(
        image=ob_img.clip(THAILAND),
        description=name_v3,
        folder=FOLDER,
        fileNamePrefix=name_v3,
        scale=SCALE_90M,
        crs=CRS,
        region=THAILAND,
        maxPixels=int(MAX_PIXELS),
        fileFormat='GeoTIFF',
    )
    task_v3.start()
    tasks.append((name_v3, task_v3))
    print(f'  Queued: {name_v3}')

    return tasks


def wait_for_tasks(tasks, poll_seconds=60):
    print(f'\nWaiting for {len(tasks)} export tasks to complete...')
    print('(GEE batch jobs typically take 5-30 minutes depending on server load)\n')
    pending = list(tasks)
    while pending:
        still_pending = []
        for name, task in pending:
            status = task.status()
            state  = status['state']
            if state == 'COMPLETED':
                print(f'  DONE:    {name}')
            elif state == 'FAILED':
                print(f'  FAILED:  {name}  error={status.get("error_message","?")}')
            elif state in ('CANCEL_REQUESTED', 'CANCELLED'):
                print(f'  CANCELLED: {name}')
            else:
                still_pending.append((name, task))
        pending = still_pending
        if pending:
            names = ', '.join(n for n, _ in pending)
            print(f'  [{time.strftime("%H:%M:%S")}] Still running: {names}')
            time.sleep(poll_seconds)

    print('\nAll tasks finished.')
    print(f'Download the 4 .tif files from Google Drive -> {FOLDER}/')
    print('Place them in: D:\\Clude Code GIS\\Energy\\Energy map\\')


if __name__ == '__main__':
    tasks = submit_tasks()
    wait_for_tasks(tasks)
