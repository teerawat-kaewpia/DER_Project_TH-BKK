/**
 * Google Open Buildings v3 -> building presence, ALL of THAILAND (auto-tiled)
 * ==========================================================================
 * Thailand-wide generalisation of run_bangkok_buildings_export.js.
 *
 * WHY TILING IS MANDATORY HERE (unlike Bangkok):
 *   The Bangkok bbox at 30 m is ~3.8M px and exports in ONE task. Thailand is
 *   vastly larger — at 30 m it is ~29,600 x 55,700 px (~1.65 billion px), and
 *   even at 90 m it is ~9,900 x 18,600 px. Both exceed GEE's per-reprojection
 *   output cap (which failed at 15,030 px in one dimension). So the single-
 *   export trick that works for Bangkok cannot work nationally: the bbox is
 *   split into an nx * ny grid, each tile kept under MAX_TILE_PX per side, and
 *   each tile exported separately. Mosaic the tiles locally after download.
 *
 * METHOD (same as Bangkok presence):
 *   paint() rasterises the v3 footprint polygons directly onto the target grid
 *   (any cell touched by a building = 1). No fine native render, no
 *   reduceResolution -> no reprojection blow-up within a tile.
 *
 * RESOLUTION:
 *   SCALE_M = 90 (default) matches the province analysis rasters -> 1x2 = 2 tiles.
 *   Set SCALE_M = 30 for the fine, Bangkok-comparable layer -> 3x6 = 18 tiles
 *   (many more Tasks to RUN and files to mosaic).
 *
 * Output (Drive -> DER_Thailand_Buildings/):
 *   GoogleOB_v3_presence_<SCALE>m_Thailand_r<row>c<col>.tif   (0/1 presence)
 *
 * Usage:
 *   1. Paste into a new script at code.earthengine.google.com
 *   2. Click "Run" -- read the printed tile count in the Console
 *   3. Open the "Tasks" tab and click "RUN" on every tile task
 *   4. Download all tiles from Drive -> DER_Thailand_Buildings/, then mosaic:
 *        gdal_merge.py -o GoogleOB_v3_presence_90m_Thailand.tif \
 *            GoogleOB_v3_presence_90m_Thailand_r*c*.tif
 *      (or QGIS -> Raster -> Miscellaneous -> Merge)
 */

// ---- config ----
var THAILAND    = ee.Geometry.Rectangle([97.5, 5.5, 105.7, 20.5]);
var CRS         = 'EPSG:4326';
var SCALE_M     = 30;      // 30 = fine, Bangkok-comparable (3x6 = 18 tiles); 90 = province-matched (2 tiles)
var MAX_TILE_PX = 10000;   // safe margin below the ~15,000 px reprojection cap
var MAX_PIXELS  = 5e8;
var FOLDER      = 'DER_Thailand_Buildings';

// ---- auto-compute the tile grid from bbox size at SCALE_M ----
var b = THAILAND.bounds().getInfo().coordinates[0];
var xMin = b[0][0], yMin = b[0][1], xMax = b[2][0], yMax = b[2][1];
var midLat   = (yMin + yMax) / 2;
var mPerLat  = 111320;
var mPerLon  = 111320 * Math.cos(midLat * Math.PI / 180);
var widthPx  = (xMax - xMin) * mPerLon / SCALE_M;
var heightPx = (yMax - yMin) * mPerLat / SCALE_M;
var nx = Math.max(1, Math.ceil(widthPx  / MAX_TILE_PX));
var ny = Math.max(1, Math.ceil(heightPx / MAX_TILE_PX));
var dx = (xMax - xMin) / nx;
var dy = (yMax - yMin) / ny;
print('Full grid px:', Math.round(widthPx) + ' x ' + Math.round(heightPx),
      '| tiles:', nx + ' x ' + ny + ' = ' + (nx * ny),
      '| SCALE_M =', SCALE_M);

// ---- v3 footprints ----
var obV3 = ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons');
var presence = ee.Image().byte().paint(obV3.filterBounds(THAILAND), 1).unmask(0)
    .reproject({crs: CRS, scale: SCALE_M})
    .rename('building_presence');

// optional coarse preview (comment out if slow)
Map.centerObject(THAILAND, 6);
Map.addLayer(presence.clip(THAILAND),
    {min: 0, max: 1, palette: ['ffffff', 'd73027']}, 'Building presence', false);

// ---- export each tile ----
for (var row = 0; row < ny; row++) {
  for (var col = 0; col < nx; col++) {
    var tile = ee.Geometry.Rectangle([
      xMin + col * dx,       yMin + row * dy,
      xMin + (col + 1) * dx, yMin + (row + 1) * dy
    ]);
    var name = 'GoogleOB_v3_presence_' + SCALE_M + 'm_Thailand_r' + row + 'c' + col;
    Export.image.toDrive({
      image: presence.clip(tile),
      description: name,
      folder: FOLDER,
      fileNamePrefix: name,
      scale: SCALE_M,
      crs: CRS,
      region: tile,
      maxPixels: MAX_PIXELS,
      fileFormat: 'GeoTIFF'
    });
    print('Queued:', name);
  }
}
print(nx * ny, 'tiles queued -- RUN each in the Tasks tab, then mosaic locally.');
