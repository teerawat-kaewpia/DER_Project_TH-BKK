# -*- coding: utf-8 -*-
"""
Google Open Buildings v3 -> building presence, ALL of THAILAND (auto-tiled).
Python / command-line twin of run_thailand_buildings_export.js.

WHY TILING IS MANDATORY HERE (unlike Bangkok):
  Bangkok at 30 m is ~3.8M px and exports in one task. Thailand is far larger
  — ~29,600 x 55,700 px at 30 m (~1.65 billion), and ~9,900 x 18,600 px even at
  90 m. Both exceed GEE's per-reprojection cap (failed at 15,030 px in one
  dimension). So the bbox is split into an nx*ny grid, each tile kept under
  MAX_TILE_PX per side, and each tile exported separately; mosaic locally.

METHOD (same as Bangkok presence): paint() rasterises the v3 footprint polygons
directly onto the target grid (any touched cell = 1). No fine native render,
no reduceResolution -> no reprojection blow-up within a tile.

RESOLUTION: SCALE_M = 90 (default) matches the province rasters -> 1x2 = 2 tiles.
Set SCALE_M = 30 for the fine, Bangkok-comparable layer -> 3x6 = 18 tiles.

Output (Drive -> DER_Thailand_Buildings/):
  GoogleOB_v3_presence_<SCALE>m_Thailand_r<row>c<col>.tif   (0/1 presence)

Usage:
  1) earthengine authenticate      (one-time)
  2) python run_thailand_buildings_export.py
  3) Download all tiles, then mosaic:
       gdal_merge.py -o GoogleOB_v3_presence_90m_Thailand.tif \
           GoogleOB_v3_presence_90m_Thailand_r*c*.tif
"""

import math
import time
import ee

# ---- config ----
PROJECT     = 'ee-teerawat'
THAILAND    = ee.Geometry.Rectangle([97.5, 5.5, 105.7, 20.5])
CRS         = 'EPSG:4326'
SCALE_M     = 30       # 30 = fine, Bangkok-comparable (3x6 = 18 tiles); 90 = province-matched (2 tiles)
MAX_TILE_PX = 10000    # safe margin below the ~15,000 px reprojection cap
MAX_PIXELS  = 5e8
FOLDER      = 'DER_Thailand_Buildings'

# bbox corners (literals above)
X_MIN, Y_MIN, X_MAX, Y_MAX = 97.5, 5.5, 105.7, 20.5


def tile_grid():
    mid_lat  = (Y_MIN + Y_MAX) / 2
    m_per_lat = 111320
    m_per_lon = 111320 * math.cos(math.radians(mid_lat))
    width_px  = (X_MAX - X_MIN) * m_per_lon / SCALE_M
    height_px = (Y_MAX - Y_MIN) * m_per_lat / SCALE_M
    nx = max(1, math.ceil(width_px / MAX_TILE_PX))
    ny = max(1, math.ceil(height_px / MAX_TILE_PX))
    print(f'Full grid px: {width_px:.0f} x {height_px:.0f} | '
          f'tiles: {nx} x {ny} = {nx*ny} | SCALE_M = {SCALE_M}')
    return nx, ny


def submit_tasks():
    ee.Initialize(project=PROJECT)
    print(f'GEE initialized (project={PROJECT})')

    obV3 = ee.FeatureCollection('GOOGLE/Research/open-buildings/v3/polygons')
    presence = (ee.Image().byte().paint(obV3.filterBounds(THAILAND), 1).unmask(0)
                .reproject(crs=CRS, scale=SCALE_M)
                .rename('building_presence'))

    nx, ny = tile_grid()
    dx = (X_MAX - X_MIN) / nx
    dy = (Y_MAX - Y_MIN) / ny

    tasks = []
    for row in range(ny):
        for col in range(nx):
            tile = ee.Geometry.Rectangle([
                X_MIN + col * dx,       Y_MIN + row * dy,
                X_MIN + (col + 1) * dx, Y_MIN + (row + 1) * dy,
            ])
            name = f'GoogleOB_v3_presence_{SCALE_M}m_Thailand_r{row}c{col}'
            task = ee.batch.Export.image.toDrive(
                image=presence.clip(tile),
                description=name,
                folder=FOLDER,
                fileNamePrefix=name,
                scale=SCALE_M,
                crs=CRS,
                region=tile,
                maxPixels=int(MAX_PIXELS),
                fileFormat='GeoTIFF',
            )
            task.start()
            tasks.append((name, task))
            print(f'  Queued: {name}')
    print(f'{nx*ny} tiles queued -- mosaic locally after download.')
    return tasks


def wait_for_tasks(tasks, poll_seconds=60):
    print(f'\nWaiting for {len(tasks)} export task(s)...')
    pending = list(tasks)
    while pending:
        still = []
        for name, task in pending:
            st = task.status()['state']
            if st == 'COMPLETED':
                print(f'  DONE:    {name}')
            elif st == 'FAILED':
                print(f'  FAILED:  {name}  {task.status().get("error_message","?")}')
            elif st in ('CANCEL_REQUESTED', 'CANCELLED'):
                print(f'  CANCELLED: {name}')
            else:
                still.append((name, task))
        pending = still
        if pending:
            print(f'  [{time.strftime("%H:%M:%S")}] running: '
                  + ', '.join(n for n, _ in pending))
            time.sleep(poll_seconds)
    print(f'\nAll tasks finished. Download from Drive -> {FOLDER}/ and mosaic.')


if __name__ == '__main__':
    tasks = submit_tasks()
    wait_for_tasks(tasks)
