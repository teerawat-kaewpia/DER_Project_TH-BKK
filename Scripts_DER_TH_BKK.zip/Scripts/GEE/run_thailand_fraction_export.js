/**
 * Google Open Buildings 2.5D -> building FRACTION, ALL of THAILAND (auto-tiled)
 * ==========================================================================
 * Same auto-tiling pattern as run_thailand_height_export.js, but exports the
 * 2.5D Temporal building_fractional_count band (per-cell building fraction).
 *
 * WHY TILING + setDefaultProjection ARE BOTH NEEDED:
 *   Thailand at 30 m is ~9,900 x 18,600 px -- one dimension exceeds GEE's
 *   per-reprojection cap (which failed at 15,030 px), so the bbox is split into
 *   an nx * ny grid and each tile exported separately. Separately, the 2.5D
 *   source is a continuous raster at ~4 m native resolution; a mosaic() of it
 *   carries the DEFAULT 1-degree projection, so reduceResolution would try to
 *   render the ~4 m grid over the whole bbox and hit the cap. Pinning the input
 *   to its true native projection with setDefaultProjection() BEFORE
 *   reduceResolution lets GEE aggregate ~4 m native pixels straight into 30 m
 *   output cells (the fix proven on the Bangkok 2.5D exports).
 *
 * Output (Drive -> DER_Thailand_Buildings/):
 *   GoogleOB_2_5D_fraction_2023_30m_Thailand_r<row>c<col>.tif
 *
 * Usage:
 *   1. Paste into a new script at code.earthengine.google.com
 *   2. Click "Run" -- read the printed tile count and native scale in Console
 *   3. Open the "Tasks" tab and click "RUN" on every tile task
 *   4. Download all tiles, then mosaic:
 *        gdal_merge.py -o GoogleOB_2_5D_fraction_2023_30m_Thailand.tif \
 *            GoogleOB_2_5D_fraction_2023_30m_Thailand_r*c*.tif
 */

// ---- config ----
var THAILAND    = ee.Geometry.Rectangle([97.5, 5.5, 105.7, 20.5]);
var START_DATE  = '2023-01-01';
var END_DATE    = '2023-12-31';
var CRS         = 'EPSG:4326';
var SCALE_M     = 30;      // 30 = fine (3x6 = 18 tiles); 90 = province-matched (2 tiles)
var MAX_TILE_PX = 10000;   // safe margin below the ~15,000 px reprojection cap
var MAX_PIXELS  = 5e8;
var FOLDER      = 'DER_Thailand_Buildings';
var YEAR_TAG    = START_DATE.slice(0, 4);

// ---- auto-compute the tile grid from bbox size at SCALE_M ----
var b = THAILAND.bounds().getInfo().coordinates[0];
var xMin = b[0][0], yMin = b[0][1], xMax = b[2][0], yMax = b[2][1];
var midLat   = (yMin + yMax) / 2;
var mPerLat  = 111320;
var mPerLon  = 111320 * Math.cos(midLat * Math.PI / 180);
var widthPx  = (xMax - xMin) * mPerLon / SCALE_M;
var heightPx = (yMax - yMin) * mPerLat / SCALE_M;
var nx = Math.max(1, Math.ceil(widthPx  / MAX_TILE_PX));
var ny = Math.max(1, Math.ceil(heightPx / MAX_TILE_PX));
var dx = (xMax - xMin) / nx;
var dy = (yMax - yMin) / ny;
print('Full grid px:', Math.round(widthPx) + ' x ' + Math.round(heightPx),
      '| tiles:', nx + ' x ' + ny + ' = ' + (nx * ny),
      '| SCALE_M =', SCALE_M);

// ---- 2.5D Temporal building fraction, aggregated to 30 m ----
var col = ee.ImageCollection('GOOGLE/Research/open-buildings-temporal/v1')
    .filterDate(START_DATE, END_DATE)
    .filterBounds(THAILAND);
print('2.5D images for', START_DATE, 'to', END_DATE, ':', col.size());

// native projection of the source (~4 m); required so reduceResolution does NOT
// fall back to reprojecting a 1-degree mosaic over the full bbox.
var nativeProj = col.first().select('building_fractional_count').projection();
print('native scale (m):', nativeProj.nominalScale());

var fraction = col.select('building_fractional_count').mosaic()
    .setDefaultProjection(nativeProj)
    .reduceResolution({reducer: ee.Reducer.mean(), bestEffort: true, maxPixels: 1024})
    .reproject({crs: CRS, scale: SCALE_M})
    .rename('building_fractional_count');

// optional coarse preview (comment out if slow)
Map.centerObject(THAILAND, 6);
Map.addLayer(fraction.clip(THAILAND),
    {min: 0, max: 1, palette: ['ffffff', 'fee090', 'd73027']}, 'Building fraction', false);

// ---- export each tile ----
for (var row = 0; row < ny; row++) {
  for (var col2 = 0; col2 < nx; col2++) {
    var tile = ee.Geometry.Rectangle([
      xMin + col2 * dx,       yMin + row * dy,
      xMin + (col2 + 1) * dx, yMin + (row + 1) * dy
    ]);
    var name = 'GoogleOB_2_5D_fraction_' + YEAR_TAG + '_' + SCALE_M + 'm_Thailand_r' + row + 'c' + col2;
    Export.image.toDrive({
      image: fraction.clip(tile),
      description: name,
      folder: FOLDER,
      fileNamePrefix: name,
      scale: SCALE_M,
      crs: CRS,
      region: tile,
      maxPixels: MAX_PIXELS,
      fileFormat: 'GeoTIFF'
    });
    print('Queued:', name);
  }
}
print(nx * ny, 'tiles queued -- RUN each in the Tasks tab, then mosaic locally.');
